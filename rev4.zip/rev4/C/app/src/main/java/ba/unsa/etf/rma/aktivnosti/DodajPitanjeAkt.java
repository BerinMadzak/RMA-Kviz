package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.MogucePitanjeAdapter;
import ba.unsa.etf.rma.klase.OdgovorAdapter;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends Activity {

    private ArrayList<Pitanje> pitanja = null;
    private EditText naziv = null;
    private ArrayList<String> odgovori = new ArrayList<String>();
    private OdgovorAdapter odgovoriad = null;
    private ListView od = null;
    private EditText odgovor = null;
    private String tacan = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dodaj_pitanje);

        pitanja = getIntent().getParcelableArrayListExtra("pitanja");

        naziv = findViewById(R.id.etNaziv);

        od = findViewById(R.id.lvMogucaPitanja);


        odgovor = findViewById(R.id.etOdgovor);

        Button dodajodgovor = findViewById(R.id.btnDodajOdgovor);
        Button dodajtacan = findViewById(R.id.btnDodajTacan);
        Button spasi = findViewById(R.id.btnDodajPitanje);

        dodajodgovor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                odgovori.add(odgovor.getText().toString());
                /*odgovoriad = new OdgovorAdapter(DodajPitanjeAkt.this, odgovori);
                od.setAdapter(odgovoriad);*/
            }
        });

        dodajtacan.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                odgovori.add(odgovor.getText().toString());
                tacan = odgovor.getText().toString();
                /*odgovoriad = new OdgovorAdapter(DodajPitanjeAkt.this, odgovori);
                od.setAdapter(odgovoriad);*/
            }
        });

        spasi.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Pitanje novo = new Pitanje(naziv.getText().toString());
                novo.setOdgovori(odgovori);
                novo.setTacan(tacan);
                pitanja.add(novo);
                finish();
            }
        });

    }
}
