package ba.unsa.etf.rma;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKategorijuAkt;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijaAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizAdapter;

public class MainActivity extends Activity {

    private Spinner ka = null;
    private ListView kv = null;
    private ArrayList<Kviz> kvizovi = null;
    private ArrayList<Kategorija> kategorije = null;
    private KvizAdapter kvizadapter = null;
    private KategorijaAdapter kategorijaadapter = null;

    public ArrayList<Kategorija> getKategorije() {
        return kategorije;
    }

    public ArrayList<Kviz> getKvizovi() {
        return kvizovi;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        this.ka = findViewById(R.id.spPostojeceKategorije);
        this.kv = findViewById(R.id.lvKvizovi);
        this.kvizovi = new ArrayList<Kviz>();
        this.kategorije = new ArrayList<Kategorija>();

        kategorije.add(new Kategorija("Svi"));
        kategorije.add(new Kategorija("Pomocna"));
        kategorije.add(new Kategorija("Pomocna1"));

        kvizovi.add(new Kviz("Pomocni", kategorije.get(1)));
        kvizovi.add(new Kviz("Pomocni1", kategorije.get(2)));
        kvizovi.add(new Kviz("Dodaj Kviz"));

        kategorijaadapter = new KategorijaAdapter(this, kategorije);
        ka.setAdapter(kategorijaadapter);

        kvizadapter = new KvizAdapter(this, kvizovi);
        kv.setAdapter(kvizadapter);

        ka.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Kategorija k = (Kategorija) parent.getItemAtPosition(position);
                String nkate = k.getNaziv();

                ArrayList<Kviz> pom = kvizovi;

                if (!nkate.equalsIgnoreCase("Svi")) {

                    pom = new ArrayList<Kviz>();

                    for (int i = 0; i < kvizovi.size() - 1; i++) {
                        Kviz a = kvizovi.get(i);
                        if (a.getKategorija().getNaziv().equalsIgnoreCase(nkate)) {
                            pom.add(a);
                        }
                    }

                    pom.add(kvizovi.get(kvizovi.size() - 1));
                }

                kvizadapter = new KvizAdapter(MainActivity.this, pom);
                kv.setAdapter(kvizadapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }


        });

        kv.setClickable(true);
        kv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Kviz k = (Kviz) kv.getItemAtPosition(position);
                String nkviz = k.getNaziv();
                if (nkviz.equalsIgnoreCase("Dodaj Kviz")) {
                    Intent intent = new Intent(MainActivity.this, DodajKvizAkt.class);
                    intent.putParcelableArrayListExtra("kategorije",(ArrayList) kategorije);
                    intent.putParcelableArrayListExtra("kvizovi",(ArrayList) kvizovi);
                    startActivityForResult(intent, 1);
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1)
        {
            kvizovi = data.getParcelableArrayListExtra("kvizovi");

            kvizadapter = new KvizAdapter(MainActivity.this, kvizovi);
            kv.setAdapter(kvizadapter);
        }
    }

}

