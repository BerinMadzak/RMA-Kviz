package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class MogucePitanjeAdapter extends ArrayAdapter<Pitanje> {

    public MogucePitanjeAdapter(@NonNull Context context, ArrayList<Pitanje> pitanja) {
        super(context, 0, pitanja);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent){

        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.pitanje_u_listi,
                    parent, false);
        }

        ImageView ikona = convertView.findViewById(R.id.ikonapitanja);
        TextView naziv = convertView.findViewById(R.id.nazivpitanja);

        Pitanje pitanje = getItem(position);

        ikona.setImageResource(R.drawable.plus);
        naziv.setText(pitanje.getNaziv());

        return convertView;
    }

}
