package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;
import com.maltaisn.icondialog.IconHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.DataWrapper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback{

   ArrayList<Kviz> kvizici;
   IconDialog dialog;
    private Icon[] selectedIcons;
    private EditText editText;
    int idIkone;



    public class DodajKategorijuTask extends AsyncTask<String,Void, Void> {
        String jsonString="";
        public void pripremiJSONKategorije(Kategorija k)
        {
            jsonString ="{ \"fields\": { \"idIkonice\": {\"integerValue\":\"";
            jsonString += k.getSlikaKategorije();
            jsonString += "\"},";
            jsonString +=  "\"naziv\": {\"stringValue\":\"";
            jsonString += k.getNaziv();
            jsonString += "\"}}}";
        }
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url ="https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = jsonString;//"{ \"fields\": { \"idKategorije\": {\"stringValue\":\"0\"}}}"; //treba promijeniti ID
                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine=null;
                    while ((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }



    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);
        DataWrapper dw2 = (DataWrapper) getIntent().getSerializableExtra("data");
        final ArrayList<Kviz> kvizovi = dw2.getKvizovi();
        final ArrayList<Kategorija> kategorije = dw2.getKategorije();
        final ArrayList<Pitanje> pitanja = dw2.getPitanja();
        final int originalnaPozicija = dw2.getLokacija();
        final IconDialog iconDialog = new IconDialog();
        Button button = findViewById(R.id.btnDodajIkonu);
        final EditText temp = (EditText) findViewById(R.id.etIkona);
        //zabrana edita idIkone
        editText = (EditText) findViewById(R.id.etIkona);
        temp.setFocusable(false);
        temp.setClickable(false);
        //azuriranje idIkone
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
                idIkone = iconDialog.getId();
                temp.setText("" + idIkone);
            }
        });
        final Button spremi = (Button) findViewById(R.id.btnDodajKategoriju);
        spremi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //neki pokusaj necega
                IconHelper iconHelper = IconHelper.getInstance(iconDialog.getActivity());
                /* for (int i = 0; i < iconHelper.getIconCount();i++)
                    for (int j = 0; j < selectedIcons.length; j++)
                        if (i== selectedIcons[j].getId()) idIkone=i;*/
                temp.setText("" + selectedIcons[0].getId());
              //  kvizovi.add(new Kviz("KvizNeki", R.drawable.ic_launcher_background));
                //
                EditText naziv = findViewById(R.id.etNaziv);
                String tekstNaziva = naziv.getText().toString();
                boolean postojiIstiNaziv=false;
                //doSomething(iconDialog.getActivity());
                for (int i = 0; i < kategorije.size(); i++)
                    if (kategorije.get(i).getNaziv().toString().equals(tekstNaziva)) postojiIstiNaziv=true;
                if (tekstNaziva.length() != 0 && !postojiIstiNaziv) {
                    //radimo posao prenosa svega
                    Kategorija kat = new Kategorija(tekstNaziva, selectedIcons[0].getId());
                    boolean ispravan= true;
                        kat.setIndikator(1);
                        kategorije.add(0, kat);
                        DodajKategorijuTask dk = new DodajKategorijuTask();
                        dk.pripremiJSONKategorije(kat);
                        dk.execute("proba");
                    Intent dodavanjeKategorije = new Intent(DodajKategorijuAkt.this, KvizoviAkt.class);
                    dodavanjeKategorije.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, originalnaPozicija));
                    startActivity(dodavanjeKategorije);
                }
                //ne smijemo dozvoliti prazan odgovor pa bojimo pozadinu elementa etOdgovor u crveno
                else
                {
                    naziv.setBackgroundColor(Color.RED);
                    AlertDialog.Builder greskaNaziv = new AlertDialog.Builder(DodajKategorijuAkt.this);
                    greskaNaziv.setMessage("Unesena kategorija već postoji!");
                    greskaNaziv.setPositiveButton("OK", null);
                    AlertDialog Naziv = greskaNaziv.create();
                    Naziv.show();
                }

            }
        });
        kvizici=kvizovi;
        dialog=iconDialog;
    }
    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {

        selectedIcons = icons;
        editText.setText(""+selectedIcons[0].getId());
    }
}
