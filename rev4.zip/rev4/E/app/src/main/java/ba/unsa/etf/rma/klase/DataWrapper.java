package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DataWrapper implements Serializable {
    ArrayList<Kviz> kvizovi = new ArrayList<>();

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public int getLokacija() {
        return lokacija;
    }

    int lokacija;


    ArrayList<Pitanje> pitanja = new ArrayList<>();
    public DataWrapper(ArrayList<Kviz> kvizovi, ArrayList<Kategorija> kategorije, ArrayList<Pitanje> pitanja, int lokacija) {
        this.kvizovi = kvizovi;
        this.kategorije = kategorije;
       this.pitanja=pitanja;
       this.lokacija=lokacija;
    }

    public ArrayList<Kviz> getKvizovi() {
        return kvizovi;
    }

    public ArrayList<Kategorija> getKategorije() {
        return kategorije;
    }


    ArrayList<Kategorija> kategorije = new ArrayList<>();
}
