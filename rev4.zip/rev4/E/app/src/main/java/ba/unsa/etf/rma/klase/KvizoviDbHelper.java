package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_CREATE_KATEGORIJE;
import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_CREATE_KVIZOVI;
import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_CREATE_PITANJA;
import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_CREATE_RANGLISTE;
import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_DELETE_KATEGORIJE;
import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_DELETE_KVIZOVI;
import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_DELETE_PITANJA;
import static ba.unsa.etf.rma.klase.BazaKoncept.SQL_DELETE_RANGLISTE;

public class KvizoviDbHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 2;
    public static final String DATABASE_NAME = "KvizoviAktLokalna.db";

    public KvizoviDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_KATEGORIJE);
        db.execSQL(SQL_CREATE_KVIZOVI);
        db.execSQL(SQL_CREATE_PITANJA);
        db.execSQL(SQL_CREATE_RANGLISTE);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_KATEGORIJE);
        db.execSQL(SQL_DELETE_KVIZOVI);
        db.execSQL(SQL_DELETE_PITANJA);
        db.execSQL(SQL_DELETE_RANGLISTE);
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
