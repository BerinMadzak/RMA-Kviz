package ba.unsa.etf.rma.klase;

import android.provider.BaseColumns;

public class BazaKoncept {
    private BazaKoncept() {}

    //da bismo pojednostavili proces u bazi čuvamo samo JSON elemente koje kreiramo
    public static class KategorijeSQL implements BaseColumns {
        public static final String TABLE_NAME = "Kategorije";
        public static final String JSONKategorijeSQL = "JSON_kategorije";
    }
    public static class KvizoviSQL implements BaseColumns {
        public static final String TABLE_NAME = "Kvizovi";
        public static final String JSONKvizoviSQL = "JSON_kvizovi";
    }
    public static class RanglisteSQL implements BaseColumns {
        public static final String TABLE_NAME = "Ranglista";
        public static final String JSONRanglisteSQL = "JSON_ranglista";
    }
    public static class PitanjaSQL implements BaseColumns {
        public static final String TABLE_NAME = "Pitanje";
        public static final String JSONPitanjaSQL = "JSON_pitanja";
    }
    public static final String SQL_CREATE_KATEGORIJE =
            "CREATE TABLE " + KategorijeSQL.TABLE_NAME + " (" +
                    KategorijeSQL._ID + " INTEGER PRIMARY KEY," +
                    KategorijeSQL.JSONKategorijeSQL + " TEXT)";
    public static final String SQL_CREATE_KVIZOVI =
            "CREATE TABLE " + KvizoviSQL.TABLE_NAME + " (" +
                    KvizoviSQL._ID + " INTEGER PRIMARY KEY," +
                    KvizoviSQL.JSONKvizoviSQL + " TEXT)";
    public static final String SQL_CREATE_RANGLISTE =
            "CREATE TABLE " + RanglisteSQL.TABLE_NAME + " (" +
                    RanglisteSQL._ID + " INTEGER PRIMARY KEY," +
                    RanglisteSQL.JSONRanglisteSQL + " TEXT)";
    public static final String SQL_CREATE_PITANJA =
            "CREATE TABLE " + PitanjaSQL.TABLE_NAME + " (" +
                    PitanjaSQL._ID + " INTEGER PRIMARY KEY," +
                    PitanjaSQL.JSONPitanjaSQL + " TEXT)";

    public static final String SQL_DELETE_KATEGORIJE =
            "DROP TABLE IF EXISTS " + KategorijeSQL.TABLE_NAME;
    public static final String SQL_DELETE_KVIZOVI =
            "DROP TABLE IF EXISTS " + KvizoviSQL.TABLE_NAME;
    public static final String SQL_DELETE_RANGLISTE =
            "DROP TABLE IF EXISTS " + RanglisteSQL.TABLE_NAME;
    public static final String SQL_DELETE_PITANJA =
            "DROP TABLE IF EXISTS " + PitanjaSQL.TABLE_NAME;

}
