package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.CustomAdapterPitanje;
import ba.unsa.etf.rma.klase.DataWrapper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends AppCompatActivity implements IDohvatiPitanjeDone {
    private int brojacSpinnera=0;
    Spinner spinnerKategorije;
    ArrayAdapter<Kategorija> dataAdapter2;
    CustomAdapterPitanje adapter, adapter2;
    ListView mojaLista, mogucaLista;
    ArrayList<Kviz> kvizovi;
    ArrayList<Kategorija> kategorije;
    ArrayList<Pitanje> pitanja;
    ArrayList<Pitanje> trenutnaPitanja;
    String JSONKvizovi="";
    final int READ_REQ = 42;


    public class DodajPitanjeTask extends AsyncTask<String,Void, Void> {
        String jsonString="";
        public void pripremiJSONPitanje(Pitanje p)
        {
            int tacanO=0;
            for (int i = 0; i < p.getOdgovori().size(); i++)
                if (p.getOdgovori().get(i).toString().equals(p.getTacan())) tacanO=i;

            jsonString ="{ \"fields\": { \"indexTacnog\": {\"integerValue\":\"";
            jsonString += tacanO;
            jsonString += "\"},";
            jsonString +=  "\"naziv\": {\"stringValue\":\"";
            jsonString += p.getNaziv();
            jsonString += "\"},";
            jsonString +=  "\"odgovori\": {\"arrayValue\":{\"values\":[";
            for (int i = 0; i < p.getOdgovori().size(); i++) {
                jsonString += "{\"stringValue\":\"";
                jsonString += p.getOdgovori().get(i);
                jsonString += "\"}";
                if (i!=p.getOdgovori().size()-1) jsonString += ",";
            }
            jsonString += "]}}}}";
        }
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url ="https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Pitanja?access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = jsonString;//"{ \"fields\": { \"idKategorije\": {\"stringValue\":\"0\"}}}"; //treba promijeniti ID
                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine=null;
                    while ((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }




    public class DodajKategorijuTask extends AsyncTask<String,Void, Void> {
        String jsonString="";
        public void pripremiJSONKategorije(Kategorija k)
        {
            jsonString ="{ \"fields\": { \"idIkonice\": {\"integerValue\":\"";
            jsonString += k.getSlikaKategorije();
            jsonString += "\"},";
            jsonString +=  "\"naziv\": {\"stringValue\":\"";
            jsonString += k.getNaziv();
            jsonString += "\"}}}";
        }
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url ="https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = jsonString;//"{ \"fields\": { \"idKategorije\": {\"stringValue\":\"0\"}}}"; //treba promijeniti ID
                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine=null;
                    while ((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }



    @Override
    public void gotovo(String json) {
        JSONKvizovi=json;
    }

    public ArrayList<Pitanje> parsirajPitanja(String json)
    {
        ArrayList<Pitanje> list = new ArrayList<Pitanje>();
        try {
            int indeks = 0;
            String qName = "";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<String> answerList = new ArrayList<String>();
                JSONObject jObject = dokumenti.getJSONObject(j);
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("indexTacnog") && fields.getJSONObject("indexTacnog").has("integerValue")) {
                    indeks = fields.getJSONObject("indexTacnog").getInt("integerValue");
                }
                if (fields.has("naziv") && fields.getJSONObject("naziv").has("stringValue")) {
                    qName = fields.getJSONObject("naziv").getString("stringValue");
                }
                JSONArray answerArray = fields.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                for (int i = 0; i < answerArray.length(); i++) {
                    try {
                        String answer= answerArray.getJSONObject(i).getString("stringValue");
                        answerList.add(answer);
                    } catch (JSONException e) {

                        Log.d("OOPS", qName);
                    }
                }
                list.add(new Pitanje(qName, qName, answerList, answerList.get(indeks), 0));
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }

    public class DohvatiPitanjeTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Pitanja?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovo(jsonString);
                  //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiPitanjeDone poziv;

        public DohvatiPitanjeTask(IDohvatiPitanjeDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
          poziv.gotovo(jsonString);
          dajStringBa();
        }
    }
    public class DodajKvizTask extends AsyncTask<String,Void, Void> {
        String jsonString="", imeKviza="";
        public void pripremiJSONKviz(Kviz k)
        {
            imeKviza = k.getNaziv().trim();
            imeKviza = imeKviza.replaceAll("\\s+","_");
            k.setIdUBazi(imeKviza);
            jsonString ="{ \"fields\": { \"idKategorije\": {\"stringValue\":\"";
            jsonString += k.getKategorija().getId();
            jsonString += "\"},";
            jsonString +=  "\"naziv\": {\"stringValue\":\"";
            jsonString += k.getNaziv();
            jsonString += "\"},";
            jsonString +=  "\"pitanja\": {\"arrayValue\":{\"values\":[";
            for (int i = 0; i < trenutnaPitanja.size()-1; i++) {
                jsonString += "{\"stringValue\":\"";
                    jsonString += trenutnaPitanja.get(i).getIdUBazi();
                    jsonString += "\"}";
                    if (i != trenutnaPitanja.size() - 2) jsonString += ",";

            }
            jsonString += "]}}}}";
        }
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url ="https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kvizovi?documentId=";
                //ovdje cemo iskoristiti dobar fol za preimenovanje
                url += imeKviza;
                url += "&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = jsonString;//"{ \"fields\": { \"idKategorije\": {\"stringValue\":\"0\"}}}"; //treba promijeniti ID
                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine=null;
                    while ((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class AzurirajKvizTask extends AsyncTask<String,Void, Void> {
        String jsonString="", imeKviza="";
        public void pripremiJSONKviz(Kviz k)
        {
            imeKviza = k.getNaziv().trim();
            imeKviza = imeKviza.replaceAll("\\s+","_");
            k.setIdUBazi(imeKviza);
            jsonString ="{ \"fields\": { \"idKategorije\": {\"stringValue\":\"";
            jsonString += k.getKategorija().getId();
            jsonString += "\"},";
            jsonString +=  "\"naziv\": {\"stringValue\":\"";
            jsonString += k.getNaziv();
            jsonString += "\"},";
            jsonString +=  "\"pitanja\": {\"arrayValue\":{\"values\":[";
            for (int i = 0; i < trenutnaPitanja.size()-1; i++) {
                jsonString += "{\"stringValue\":\"";
                jsonString += trenutnaPitanja.get(i).getIdUBazi();
                jsonString += "\"}";
                if (i != trenutnaPitanja.size() - 2) jsonString += ",";

            }
            jsonString += "]}}}}";
        }
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url ="https://firestore.googleapis.com/v1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kvizovi/";
                //ovdje cemo iskoristiti dobar fol za preimenovanje
                url += imeKviza;
                url += "?currentDocument.exists=true&access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = jsonString;//"{ \"fields\": { \"idKategorije\": {\"stringValue\":\"0\"}}}"; //treba promijeniti ID
                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine=null;
                    while ((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        //kupi iz prethodne aktivnosti
        DataWrapper dw2 = (DataWrapper) getIntent().getSerializableExtra("data");
             kvizovi = dw2.getKvizovi();
             kategorije = dw2.getKategorije();
             pitanja = dw2.getPitanja();
        final int originalnaPozicija = dw2.getLokacija();
        EditText nazivKviza = (EditText) findViewById(R.id.etNaziv);
        if (originalnaPozicija!=-1)
        nazivKviza.setText(kvizovi.get(originalnaPozicija).getNaziv());
        //ucitavanje kategorija u spinner
        final ArrayList<Kategorija> kopijaKategorija= (ArrayList<Kategorija>) kategorije.clone();
        Kategorija dodavanjeK = new Kategorija("Dodaj kategoriju", R.mipmap.ic_launcher);
        if (!kopijaKategorija.contains(dodavanjeK)) //ako ima samo opcija za sve kategorije_list
        kopijaKategorija.add(dodavanjeK);
        spinnerKategorije = (Spinner) findViewById(R.id.spKategorije);
        dataAdapter2 = new ArrayAdapter<Kategorija>(this,
                android.R.layout.simple_spinner_item, kopijaKategorija);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerKategorije.setAdapter(dataAdapter2);
        //pitanja
         trenutnaPitanja = (ArrayList<Pitanje>) pitanja.clone();
        DohvatiPitanjeTask dpt = new DohvatiPitanjeTask(DodajKvizAkt.this);
        try {
            dpt.execute().get(); //get?
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        boolean ima=false;
        final ArrayList<Pitanje> mogucaPitanja =new ArrayList<>();
        mogucaPitanja.addAll(parsirajPitanja(JSONKvizovi));
        //FLAG
        //trenutnaPitanja.add(new Pitanje(JSONKvizovi, R.drawable.ic_launcher_background));
        //FLAG
        for (int i = 0; i < pitanja.size(); i++)
            if (pitanja.get(i).getNaziv().equals("Dodaj Pitanje"))//dodaje samo ako nije cirkularni intent
                ima=true;
            if (ima==false)  trenutnaPitanja.add(new Pitanje("Dodaj Pitanje", R.drawable.ic_launcher_background));
        //  ArrayAdapter adapter = new ArrayAdapter<> (this, android.R.layout.simple_list_item_1, k.getPitanja());
        mojaLista = (ListView) findViewById(R.id.lvDodanaPitanja);
        adapter = new CustomAdapterPitanje(this, R.layout.lista, trenutnaPitanja);

        mojaLista.setAdapter(adapter);
        //ciscenje duplikata
        for (int j = 0; j < trenutnaPitanja.size(); j++)
        for (int i = 0; i < mogucaPitanja.size(); i++)
            if (trenutnaPitanja.get(j).getNaziv().equals(mogucaPitanja.get(i).getNaziv())) mogucaPitanja.remove(i);

        mogucaLista = (ListView) findViewById(R.id.lvMogucaPitanja);

        adapter2 = new CustomAdapterPitanje(this, R.layout.lista, mogucaPitanja);

        mogucaLista.setAdapter(adapter2);

            //TODO: Ucitaj pitanja

            //FLAG
       // pitanja.add(0, new Pitanje("Testno pitanje", R.mipmap.ic_launcher));

            mojaLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterac, View view, int position, long arg) {
                    //CustomAdapterPitanje adapter = new CustomAdapterPitanje(this, R.layout.lista, pitanja);
                    int pozicijaDodavanja = mojaLista.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (pozicijaDodavanja!=position) {
                        mogucaPitanja.add(trenutnaPitanja.get(position));
                        trenutnaPitanja.remove(position);
                        adapter.notifyDataSetChanged();
                        adapter2.notifyDataSetChanged();
                    }
                    else {
                        Intent dodavanje = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                            dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, originalnaPozicija));

                        startActivity(dodavanje);
                    }
                }
            });

        mogucaLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterac, View view, int position, long arg) {
                //CustomAdapterPitanje adapter = new CustomAdapterPitanje(this, R.layout.lista, pitanja);
                    trenutnaPitanja.add(0, mogucaPitanja.get(position));
                    mogucaPitanja.remove(position);
                    adapter.notifyDataSetChanged();
                    adapter2.notifyDataSetChanged();
            }
        });

        spinnerKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterac, View view, int position, long arg) {
                //CustomAdapterPitanje adapter = new CustomAdapterPitanje(this, R.layout.lista, pitanja);
                int pozicijaDodavanja = spinnerKategorije.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                brojacSpinnera+=1;
                if (adapterac.getItemAtPosition(position).toString().equals("Dodaj kategoriju") && brojacSpinnera>1) {
                    Intent dodavanjeKategorije = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    dodavanjeKategorije.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, originalnaPozicija));
                    startActivity(dodavanjeKategorije);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parentView)
            {

            }
        });

        final Button spremi = (Button) findViewById(R.id.btnDodajKviz);
        spremi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText naziv = findViewById(R.id.etNaziv);
                String tekstNaziva = naziv.getText().toString();
                //Drawable originalnaBoja = odgovor.getBackground();
                //ne smije biti isti naziv kviza
                boolean postojiIstiNaziv=false;
                for (int i = 0; i < kvizovi.size(); i++)
                    if (kvizovi.get(i).getNaziv().toString().equals(tekstNaziva)) postojiIstiNaziv=true;
                if (tekstNaziva.length()!=0 && originalnaPozicija==-1 && !postojiIstiNaziv)
                {
                    //radimo posao prenosa svega
                    Kategorija temp = (Kategorija) spinnerKategorije.getSelectedItem();
                    Kviz k;
                    if(temp.getIndikator()==0) {
                        k=new Kviz(tekstNaziva, trenutnaPitanja, (Kategorija) spinnerKategorije.getSelectedItem(), R.mipmap.ic_launcher);
                        kvizovi.add(0, k);
                    }
                    else {
                        k = new Kviz(tekstNaziva, trenutnaPitanja, (Kategorija) spinnerKategorije.getSelectedItem(), temp.getSlikaKategorije());
                        kvizovi.add(0, k);
                    }
                        Intent dodavanjePitanja = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    //FLAG ZA PRVO DODAVANJE
                    DodajKvizTask d = new DodajKvizTask();
                    d.pripremiJSONKviz(k);
                    d.execute("proba");
                    //FLAG
                    dodavanjePitanja.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                    startActivity(dodavanjePitanja);
                }
                else if (tekstNaziva.length()!=0 && originalnaPozicija!=-1)
                {
                    Kategorija temp = (Kategorija) spinnerKategorije.getSelectedItem();
                    Kviz k;
                    //radimo posao prenosa svega
                    if (temp.getIndikator()==0) {
                        k=new Kviz(tekstNaziva, trenutnaPitanja, (Kategorija) spinnerKategorije.getSelectedItem(), R.mipmap.ic_launcher);
                        kvizovi.set(originalnaPozicija, k);
                    }
                    else {
                        k=new Kviz(tekstNaziva, trenutnaPitanja, (Kategorija) spinnerKategorije.getSelectedItem(), temp.getSlikaKategorije());
                        kvizovi.set(originalnaPozicija, k);
                    }
                    Intent dodavanjePitanja = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    //FLAG ZA UPDATE
                    AzurirajKvizTask d = new AzurirajKvizTask();
                    d.pripremiJSONKviz(k);
                    d.execute("proba");
                    //FLAG
                    dodavanjePitanja.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(originalnaPozicija).getPitanja(), originalnaPozicija));
                    startActivity(dodavanjePitanja);
                }
                //ne smijemo dozvoliti prazan odgovor pa bojimo pozadinu elementa etOdgovor u crveno
                else naziv.setBackgroundColor(Color.RED);

            }
        });
        final Button importuj = (Button) findViewById(R.id.btnImportKviz);
        importuj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");

                startActivityForResult(intent, READ_REQ);
            }
        });



        //boolean contains = Arrays.stream(mogucaPitanja).anyMatch(pitanja::equals);
    }
    public String procistiString (String str)
    {
        str = str.replace("\n", "");
        //str = str.replace(",", "");
        return str;
    }
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {

        if (resultCode == Activity.RESULT_OK) {

            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();

            }
            if(requestCode == READ_REQ)
            {
                InputStream inputStream = null;
                try {
                    int brojacLinija=0;
                    inputStream = getContentResolver().openInputStream(uri);
                    BufferedReader r = new BufferedReader(new InputStreamReader(
                            inputStream));
                    StringBuilder total = new StringBuilder();
                    for (String line; (line = r.readLine()) != null; ) {
                        total.append(line).append("\n");
                        brojacLinija++;
                    }
                    /*Toast.makeText(getApplicationContext(), total.toString(),
                            Toast.LENGTH_LONG).show();*/
                   //izrezemo string
                    StringTokenizer tokens = new StringTokenizer(total.toString(), ",");


                    String nazivKviza = tokens.nextToken();
                    String nazivKategorije = tokens.nextToken();
                    String brojPitanja = tokens.nextToken(",\n");
                    int brPitanja = Integer.parseInt(brojPitanja);
                    //provjera postojanja kviza
                    boolean ispravan=true;
                    for (int i = 0; i < kvizovi.size();i++)
                    {
                        if (kvizovi.get(i).getNaziv().equals(nazivKviza))
                        {
                            ispravan=false;
                            AlertDialog.Builder greskaNaziv = new AlertDialog.Builder(DodajKvizAkt.this);
                            trenutnaPitanja.clear();
                            trenutnaPitanja.add(new Pitanje("Dodaj Pitanje", R.drawable.ic_launcher_background));
                            greskaNaziv.setMessage("Kviz kojeg importujete već postoji!");
                            greskaNaziv.setPositiveButton("OK", null);
                            AlertDialog Naziv = greskaNaziv.create();
                            Naziv.show();
                            break;
                        }
                    }
                    if (ispravan)
                    {
                        EditText naziv = findViewById(R.id.etNaziv);
                        naziv.setText(nazivKviza, TextView.BufferType.EDITABLE);
                    }
                    //provjera ispravnosti broja trenutnaPitanja
                    if (brojacLinija!=brPitanja+1)
                    {
                        AlertDialog.Builder greskaNaziv = new AlertDialog.Builder(DodajKvizAkt.this);
                        trenutnaPitanja.clear();
                        trenutnaPitanja.add(new Pitanje("Dodaj Pitanje", R.drawable.ic_launcher_background));
                        greskaNaziv.setMessage("Kviz kojeg imporujete ima neispravan broj pitanja!");
                        greskaNaziv.setPositiveButton("OK", null);
                        AlertDialog Naziv = greskaNaziv.create();
                        Naziv.show();
                    }
                    //provjera postojanja kategorije_list i kreiranje nove ako ne postoji
                    boolean postojiKategorija=false;
                    //ako postoji selektuj
                    for (int i = 0; i < kategorije.size();i++)
                        if (kategorije.get(i).getNaziv().equals(nazivKategorije))
                        {
                            postojiKategorija=true;
                            spinnerKategorije.setSelection(i); //selektuje postojecu kategoriju
                            dataAdapter2.notifyDataSetChanged();
                        }
                    //ako ne postoji kreiraj novu
                    if(!postojiKategorija)
                    {
                        Kategorija kat = new Kategorija(nazivKategorije, R.drawable.ic_launcher_background);
                        kategorije.add(kat);
                        DodajKategorijuTask dk = new DodajKategorijuTask();
                        dk.pripremiJSONKategorije(kat);
                        dk.execute("proba");
                    }
                    while (tokens.hasMoreTokens())
                    {
                        ArrayList<String> odgovori = new ArrayList<String>();
                        String nazivPitanja = tokens.nextToken(",\n");
                      /*  Toast.makeText(getApplicationContext(), "Naziv trenutnaPitanja " + nazivPitanja,
                                Toast.LENGTH_LONG).show();*/
                        String brojOdgovora = tokens.nextToken(",");
                       /* Toast.makeText(getApplicationContext(), "Broj odgovora " + brojOdgovora,
                                Toast.LENGTH_LONG).show();*/
                        String tacanOdgovor = tokens.nextToken(",");
                        String odgovor, noviRed;
                        boolean kraj=false;
                        do {
                            odgovor = tokens.nextToken("\n");
                            String[] razdvojOdgovore = odgovor.split(",");
                            for (int i = 1; i < razdvojOdgovore.length; i++) {
                              /*  Toast.makeText(getApplicationContext(), "Odgovor: " + razdvojOdgovore[i].trim(),
                                        Toast.LENGTH_SHORT).show();*/
                                String provjera = procistiString(razdvojOdgovore[i]);
                                if (razdvojOdgovore[i].trim().length()>1)
                                    //najgluplja poruka ikad smisljena
                                {
                                    boolean ponavljaSeOdgovor=false;
                                    for (int i2=0; i2 < odgovori.size(); i2++)
                                        if (odgovori.get(i2).equals(razdvojOdgovore[i].trim()))
                                            ponavljaSeOdgovor=true;

                                        if (!ponavljaSeOdgovor)
                                    odgovori.add(razdvojOdgovore[i].trim());
                                        else
                                        {
                                            AlertDialog.Builder greskaPonavljanjeO = new AlertDialog.Builder(DodajKvizAkt.this);
                                            trenutnaPitanja.clear();
                                            trenutnaPitanja.add(new Pitanje("Dodaj Pitanje", R.drawable.ic_launcher_background));
                                            greskaPonavljanjeO.setMessage("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
                                            greskaPonavljanjeO.setPositiveButton("OK", null);
                                            AlertDialog Naziv = greskaPonavljanjeO.create();
                                            Naziv.show();
                                            break;
                                        }
                                }
                            }
                  /*           noviRed=tokens.nextToken(",");
                            if (noviRed.contains("\n"))
                            {
                                odgovori.add(procistiString(noviRed.trim()));
                                Toast.makeText(getApplicationContext(), "Odgovor: " + procistiString(noviRed.trim()),
                                        Toast.LENGTH_SHORT).show();
                            }*/
                        }while (r.readLine()!=null);
                        boolean ispravanBrOdg=true, ispravanIndexTacnog=true;
                        //provjera ukupnog broja odgovora
                        int ukupanBrojOdgovora = Integer.parseInt(brojOdgovora);
                        if (ukupanBrojOdgovora!=odgovori.size())
                        {
                            ispravanBrOdg=false;
                            AlertDialog.Builder greskaOdgovor = new AlertDialog.Builder(DodajKvizAkt.this);
                            greskaOdgovor.setMessage("Kviz kojeg importujete ima neispravan broj odgovora!");
                            trenutnaPitanja.clear();
                            trenutnaPitanja.add(new Pitanje("Dodaj Pitanje", R.drawable.ic_launcher_background));
                            greskaOdgovor.setPositiveButton("OK", null);
                            AlertDialog Naziv = greskaOdgovor.create();
                            Naziv.show();
                            break;
                        }
                        //provjera indeksa tacnog odgovora
                        int indeksTacnog = Integer.parseInt(tacanOdgovor);
                         if (indeksTacnog<0 || indeksTacnog>=ukupanBrojOdgovora)
                        {
                            ispravanIndexTacnog=false;
                            AlertDialog.Builder greskaTacanOdgovor = new AlertDialog.Builder(DodajKvizAkt.this);
                            greskaTacanOdgovor.setMessage("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
                           trenutnaPitanja.clear();
                                trenutnaPitanja.add(new Pitanje("Dodaj Pitanje", R.drawable.ic_launcher_background));
                            greskaTacanOdgovor.setPositiveButton("OK", null);
                            AlertDialog Naziv = greskaTacanOdgovor.create();
                            Naziv.show();
                            break;
                        }
                        if (ispravanBrOdg && ispravanIndexTacnog) {
                            boolean duplo=false;
                            String tacan=odgovori.get(Integer.valueOf(tacanOdgovor));
                            Pitanje pitanjce=new Pitanje(nazivPitanja, nazivPitanja, odgovori, tacan, R.drawable.ic_launcher_background);
                            for (int i = 0; i < trenutnaPitanja.size(); i++) if (trenutnaPitanja.get(i).getNaziv().equals(nazivPitanja)) duplo=true;
                            if (duplo)
                            {
                                AlertDialog.Builder greskaTacanOdgovor = new AlertDialog.Builder(DodajKvizAkt.this);
                                greskaTacanOdgovor.setMessage("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");
                                trenutnaPitanja.clear();
                                trenutnaPitanja.add(new Pitanje("Dodaj Pitanje", R.drawable.ic_launcher_background));
                                greskaTacanOdgovor.setPositiveButton("OK", null);
                                AlertDialog Naziv = greskaTacanOdgovor.create();
                                Naziv.show();
                                break;
                            }
                            else
                            {
                                trenutnaPitanja.add(0, pitanjce);
                                DodajPitanjeTask dpt = new DodajPitanjeTask();
                                dpt.pripremiJSONPitanje(pitanjce);
                                dpt.execute("proba");

                            }
                            adapter.notifyDataSetChanged();
                        }
                        adapter.notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
