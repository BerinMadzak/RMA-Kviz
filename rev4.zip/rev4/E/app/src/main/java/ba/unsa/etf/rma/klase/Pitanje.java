package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;

public class Pitanje implements Serializable {
    public Pitanje(String naziv) {
        this.naziv = naziv;
        this.tekstPitanja="";
        this.idUBazi=naziv.trim();
    }

    private String naziv;
    private String tekstPitanja;
    private ArrayList<String> odgovori = new ArrayList<String>();
    private String tacan;

    public String getIdUBazi() {
        return idUBazi;
    }

    public void setIdUBazi(String idUBazi) {
        this.idUBazi = idUBazi;
    }

    private String idUBazi;
    public boolean isPostavljenoPitanje() {
        return postavljenoPitanje;
    }

    public void setPostavljenoPitanje(boolean postavljenoPitanje) {
        this.postavljenoPitanje = postavljenoPitanje;
    }

    private boolean postavljenoPitanje = false;

    public Pitanje(String naziv, int pitanje) {
        this.naziv = naziv;
        this.slikaPitanja=pitanje;
        this.idUBazi=naziv.trim();
    }

    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan, int pitanje) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.odgovori = odgovori;
        this.tacan = tacan;
        this.slikaPitanja=pitanje;
        this.idUBazi=naziv.trim();
    }

    public int getSlikaPitanja() {
        return slikaPitanja;
    }

    public void setSlikaPitanja(int slikaPitanja) {
        this.slikaPitanja = slikaPitanja;
    }

    private int slikaPitanja;

    public ArrayList<String> dajRandomOdgovore()
    {
        java.util.Collections.shuffle(odgovori);
        return odgovori;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    @Override
    public String toString() {
        return naziv;
    }
}
