package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class RangLista implements Serializable {
    public RangLista() {
    }

    public String getImeIgraca() {
        return imeIgraca;
    }

    public void setImeIgraca(String imeIgraca) {
        this.imeIgraca = imeIgraca;
    }

    public int getPozicijaNaTabeli() {
        return pozicijaNaTabeli;
    }

    public void setPozicijaNaTabeli(int pozicijaNaTabeli) {
        this.pozicijaNaTabeli = pozicijaNaTabeli;
    }

    public String getImeOdigranogKviza() {
        return imeOdigranogKviza;
    }

    public void setImeOdigranogKviza(String imeOdigranogKviza) {
        this.imeOdigranogKviza = imeOdigranogKviza;
    }

    public int getProcenatTacnihOdgovora() {
        return procenatTacnihOdgovora;
    }

    public void setProcenatTacnihOdgovora(int procenatTacnihOdgovora) {
        this.procenatTacnihOdgovora = procenatTacnihOdgovora;
    }

    public RangLista(String imeIgraca, int pozicijaNaTabeli, String imeOdigranogKviza, int procenatTacnihOdgovora) {
        this.imeIgraca = imeIgraca;
        this.pozicijaNaTabeli = pozicijaNaTabeli;
        this.imeOdigranogKviza = imeOdigranogKviza;
        this.procenatTacnihOdgovora = procenatTacnihOdgovora;
    }

    String imeIgraca;
    int pozicijaNaTabeli;
    String imeOdigranogKviza;
    int procenatTacnihOdgovora;

    @Override
    public String toString() {
        return "RangLista{" +
                "imeIgraca='" + imeIgraca + '\'' +
                ", pozicijaNaTabeli=" + pozicijaNaTabeli +
                ", procenatTacnihOdgovora=" + procenatTacnihOdgovora +
                '}';
    }
}
