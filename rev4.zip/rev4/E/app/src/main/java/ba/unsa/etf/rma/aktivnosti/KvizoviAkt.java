package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.IconHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.BazaKoncept;
import ba.unsa.etf.rma.klase.CustomAdapterGrid;
import ba.unsa.etf.rma.klase.CustomAdapterKviz;
import ba.unsa.etf.rma.klase.DataWrapper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizoviDbHelper;
import ba.unsa.etf.rma.klase.Pitanje;

import static android.provider.CalendarContract.Events;
import static java.lang.Math.round;

public class KvizoviAkt extends AppCompatActivity implements DetailFrag.OnFragmentInteractionListener2, ListaFrag.OnFragmentInteractionListener2, ba.unsa.etf.rma.fragmenti.RanglistaFrag.OnFragmentInteractionListener2, IDohvatiPitanjeDone, IDohvatiKvizDone, IDohvatiKategorijeDone {
    boolean prviPutUcitan=true;
     ArrayList<Kviz> kvizovi;
    ArrayList<Kategorija> kategorije;
     ArrayList<Pitanje> pitanja;
     String JSONParsiranje="";
     String JSONKat="";
     boolean konektovanNaInternet = true;
//daj logiku




    String JSONKvizovi="";
    final int READ_REQ = 42;

    @Override
    public void gotovo(String json) {
        JSONKvizovi=json;
    }
    @Override
    public void gotovoKviz(String json) {
        JSONParsiranje=json;
    }
    @Override
    public void gotovoKat(String json) {JSONKat=json;}
    public ArrayList<Pitanje> parsirajPitanja(String json)
    {
        ArrayList<Pitanje> list = new ArrayList<Pitanje>();
        try {
            int indeks = 0;
            String qName = "";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<String> answerList = new ArrayList<String>();
                JSONObject jObject = dokumenti.getJSONObject(j);
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("indexTacnog") && fields.getJSONObject("indexTacnog").has("integerValue")) {
                    indeks = fields.getJSONObject("indexTacnog").getInt("integerValue");
                }
                if (fields.has("naziv") && fields.getJSONObject("naziv").has("stringValue")) {
                    qName = fields.getJSONObject("naziv").getString("stringValue");
                }
                JSONArray answerArray = fields.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                for (int i = 0; i < answerArray.length(); i++) {
                    try {
                        String answer= answerArray.getJSONObject(i).getString("stringValue");
                        answerList.add(answer);
                    } catch (JSONException e) {

                        Log.d("OOPS", qName);
                    }
                }
                list.add(new Pitanje(qName, qName, answerList, answerList.get(indeks), 0));
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }




    public class DohvatiKvizTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kvizovi?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovoKviz(jsonString);
                    //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiKvizDone poziv;

        public DohvatiKvizTask(IDohvatiKvizDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
            poziv.gotovoKviz(jsonString);
            dajStringBa();
        }
    }

    public ArrayList<Kategorija> parsirajKategorije(String json)
    {
        ArrayList<Kategorija> list = new ArrayList<Kategorija>();
        try {
            int indeks = 0;
            String qName = "";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<String> answerList = new ArrayList<String>();
                JSONObject jObject = dokumenti.getJSONObject(j);
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("idIkonice") && fields.getJSONObject("idIkonice").has("integerValue")) {
                    indeks = fields.getJSONObject("idIkonice").getInt("integerValue");
                }
                if (fields.has("naziv") && fields.getJSONObject("naziv").has("stringValue")) {
                    qName = fields.getJSONObject("naziv").getString("stringValue");
                }
                list.add(new Kategorija(qName, indeks));
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }

    public class DohvatiKategorijeTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovoKat(jsonString);
                    //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiKategorijeDone poziv;

        public DohvatiKategorijeTask(IDohvatiKategorijeDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
            poziv.gotovoKat(jsonString);
            dajStringBa();
        }
    }




    public class DohvatiPitanjeTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Pitanja?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovo(jsonString);
                    //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiPitanjeDone poziv;

        public DohvatiPitanjeTask(IDohvatiPitanjeDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
            poziv.gotovo(jsonString);
            dajStringBa();
        }
    }





    public ArrayList<Kviz> parsirajKvizove(String json)
    {
        DohvatiPitanjeTask dpt = new DohvatiPitanjeTask(KvizoviAkt.this);
        try {
            dpt.execute().get(); //get?
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ArrayList<Pitanje> svaPitanja = parsirajPitanja(JSONKvizovi);
        ArrayList<Kviz> list = new ArrayList<Kviz>();
        try {
            String idKat="";
            String qName = "";
            String ID="";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<Pitanje> answerList = new ArrayList<Pitanje>();
                JSONObject jObject = dokumenti.getJSONObject(j);
               /* JSONObject naziviDokumenata = jObject.getJSONObject("name");
                ID=naziviDokumenata.getString("name");*/
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("idKategorije") && fields.getJSONObject("idKategorije").has("stringValue")) {
                    idKat = fields.getJSONObject("idKategorije").getString("stringValue");
                }
                if (fields.has("naziv") && fields.getJSONObject("naziv").has("stringValue")) {
                    qName = fields.getJSONObject("naziv").getString("stringValue");
                }
                JSONArray answerArray = fields.getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");
                for (int i = 0; i < answerArray.length(); i++) {
                    try {
                        String answer= answerArray.getJSONObject(i).getString("stringValue");
                        for (int k = 0; k < svaPitanja.size(); k++) if (svaPitanja.get(k).getNaziv().equals(answer))
                            answerList.add(svaPitanja.get(k));
                    } catch (JSONException e) {

                        Log.d("OOPS", qName);
                    }
                }
                Kategorija kategorijaKviza = new Kategorija("nesto", R.drawable.ic_launcher_background);
                for (int i = 0; i < kategorije.size(); i++) if (kategorije.get(i).getId().equals(idKat))
                    kategorijaKviza=kategorije.get(i);
                Kviz kv=new Kviz(qName, answerList, kategorijaKviza, kategorijaKviza.getSlikaKategorije());
                kv.setIdUBazi(ID);
                list.add(kv);
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }


    public class KreirajDokumentTask extends AsyncTask<String,Void, Void> {
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));

                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                Log.d("TOKEN", TOKEN);
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        final IconHelper iconHelper = IconHelper.getInstance(getApplicationContext());
        DataWrapper dw2 = (DataWrapper) getIntent().getSerializableExtra("data");
        /*IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        getBaseContext().registerReceiver(new NetworkChangeReceiver(), intentFilter);*/
        konektovanNaInternet= getIntent().getBooleanExtra("internet", true);
        if (dw2 != null) {
            kvizovi = dw2.getKvizovi();
            kategorije = dw2.getKategorije();
            pitanja = dw2.getPitanja();
        } else {
            kvizovi = new ArrayList<Kviz>();
            kategorije = new ArrayList<Kategorija>();
            pitanja = new ArrayList<Pitanje>();
            //ucitavanje kategorija u spinner
            kategorije.add(new Kategorija("Sve", R.mipmap.ic_launcher));
            //FLAG
            if (provjeriKonekciju()) {
                DohvatiKvizTask dpt = new DohvatiKvizTask(KvizoviAkt.this);
                try {
                    dpt.execute().get(); //get?
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                DohvatiKategorijeTask dpt2 = new DohvatiKategorijeTask(KvizoviAkt.this);
                try {
                    dpt2.execute().get(); //get?
                } catch (ExecutionException e2) {
                    e2.printStackTrace();
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
            }
            //dodavanje kvizova za početni ekran
         /*   for (int i = 1; i < 5; i++) {
                kvizovi.add(new Kviz("Kviz " + i, R.mipmap.ic_launcher));
            }*/
            //kvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
        }

        //Dodajemo parsirano sa Firestore
        if (provjeriKonekciju()) {
            kvizovi.addAll(parsirajKvizove(JSONParsiranje));
            kategorije.addAll(parsirajKategorije(JSONKat));
        }
        //Kreiramo lokalnu bazu
        KvizoviDbHelper dbHelper = new KvizoviDbHelper(getBaseContext());

        //popunjavamo lokalnu bazu
        SQLiteDatabase db = dbHelper.getWritableDatabase();

// Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(BazaKoncept.KategorijeSQL.JSONKategorijeSQL, JSONKat);
        long idKategorijeSQL = db.insert(BazaKoncept.KategorijeSQL.TABLE_NAME, null, values);
        values = new ContentValues();
        values.put(BazaKoncept.KvizoviSQL.JSONKvizoviSQL, JSONParsiranje);
        long idKvizaSQL = db.insert(BazaKoncept.KvizoviSQL.TABLE_NAME, null, values);
        values = new ContentValues();
        values.put(BazaKoncept.PitanjaSQL.JSONPitanjaSQL, JSONKvizovi);
        long idPitanjaSQL = db.insert(BazaKoncept.PitanjaSQL.TABLE_NAME, null, values);

        final ArrayList<Kviz> kopijaKvizovi = (ArrayList<Kviz>) kvizovi.clone();
        // kopijaKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
        Configuration config = KvizoviAkt.this.getResources().getConfiguration();
        if (config.screenWidthDp >= 550) {
            // siroki layout
            final ListView listaKat = (ListView) findViewById(R.id.listaKategorija);
            final ArrayAdapter<Kategorija> dataAdapter = new ArrayAdapter<Kategorija>(this,
                   R.layout.kategorije_list, kategorije);
            listaKat.setAdapter(dataAdapter);
            final GridView gridView = (GridView)findViewById(R.id.gridKvizovi);
            final ArrayList<Kviz> klonKvizovi = (ArrayList<Kviz>) kvizovi.clone();
            klonKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
            final CustomAdapterGrid kvizAdapter = new CustomAdapterGrid(this, R.layout.grid_kviz, klonKvizovi);
            gridView.setAdapter(kvizAdapter);
            /*treba jos da se mijenjaju kvizovi onSelectedItem
            malo povecati font naziva kviza i slike, probati autofit sa one stranice
             */
            listaKat.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                    klonKvizovi.clear();
                    for (int i = 0; i <kvizovi.size();i++)
                        if (kvizovi.get(i).getKategorija().getNaziv().equals(kategorije.get(position).getNaziv()))
                        klonKvizovi.add(kvizovi.get(i));
                        //provjera ima li polje za dodavanje pitanja
                    {
                        boolean ima = false;
                        for (int i = 0; i < klonKvizovi.size(); i++)
                            if (klonKvizovi.get(i).getNaziv().equals("Dodaj Kviz")) ima = true;
                        if (!ima)
                            klonKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
                    }
                    kvizAdapter.notifyDataSetChanged();
                    dataAdapter.notifyDataSetChanged();
                }
        });

            //KvizoviKlik


            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                    int pozicijaDodavanja = gridView.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja && provjeriKonekciju()) { //ako klikne kratkim klikom na dodajKviz treba mu se i otvoriti DodajKvizAkt
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                        startActivity(dodavanje);
                    } else { //otvori IgrajKviz

                        //dodaj kalendar
                        addCalendar();

                        //nadji kalendar
                        final String[] EVENT_PROJECTION = new String[] {
                                CalendarContract.Calendars._ID,                           // 0
                                CalendarContract.Calendars.ACCOUNT_NAME,                  // 1
                                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,         // 2
                                CalendarContract.Calendars.OWNER_ACCOUNT                  // 3
                        };

// The indices for the projection array above.
                        final int PROJECTION_ID_INDEX = 0;
                        final int PROJECTION_ACCOUNT_NAME_INDEX = 1;
                        final int PROJECTION_DISPLAY_NAME_INDEX = 2;
                        final int PROJECTION_OWNER_ACCOUNT_INDEX = 3;
                        Cursor cur = null;
                        ContentResolver cr = getContentResolver();
                        Uri uri = CalendarContract.Calendars.CONTENT_URI;
                        String selection = "((" + CalendarContract.Calendars.ACCOUNT_NAME + " = ?) AND ("
                                + CalendarContract.Calendars.ACCOUNT_TYPE + " = ?) AND ("
                                + CalendarContract.Calendars.OWNER_ACCOUNT + " = ?))";
                        String[] selectionArgs = new String[] {"test@test.ba", "test.test.ba",
                                "test@test.ba"};
// Submit the query and get a Cursor object back.
                        cur = cr.query(uri, EVENT_PROJECTION, selection, selectionArgs, null);
                        long idKalendara = 0;
                        //pretrazujemo povratni kursor
                        while (cur.moveToNext()) {
                            idKalendara = cur.getLong(PROJECTION_ID_INDEX);

                        }
                        //precistimo kvizove za svaki slucaj
                        Kviz k = kvizovi.get(position);
                        for (int i = 0; i < k.getPitanja().size(); i++)
                            if (k.getPitanja().get(i).getNaziv().equals("Dodaj Pitanje")) k.getPitanja().remove(i);
                        //racunamo X shodno postavci
                        int X = round (k.getPitanja().size()/2);
                        //kreiramo novi dogadjaj (za testiranje, TODO: ODKOMENTIRATI AKO TREBA TESTIRATI OVU FUNKCIONALNOST!)

                        //kreirajDogadjaj(idKalendara);

                        //provjeravamo je li postoji li dogadjaj u narednih X minuta
                        ContentResolver contentResolver = KvizoviAkt.this.getContentResolver();
                        String[] projection = new String[] { CalendarContract.Events.CALENDAR_ID, CalendarContract.Events.TITLE, CalendarContract.Events.DESCRIPTION, CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND, CalendarContract.Events.ALL_DAY, CalendarContract.Events.EVENT_LOCATION };
                        // Create a cursor and read from the calendar (for Android API below 4.0)
                        Calendar startTime = Calendar.getInstance();
                        Calendar endTime = Calendar.getInstance();
                        endTime.add(Calendar.MINUTE, X);
                        String selection2 = "(( " + CalendarContract.Events.DTSTART + " >= " + startTime.getTimeInMillis() + " ) AND ( " + CalendarContract.Events.DTSTART + " <= " + endTime.getTimeInMillis() + " ))";

                        long razlikaUMinutama=0;
                        boolean imaDogadjajUKalendaru=false;
                        Cursor cursor = contentResolver.query( CalendarContract.Events.CONTENT_URI, projection, selection2, null, null );
                        if (cursor.moveToFirst())
                        {
                            imaDogadjajUKalendaru=true;
                            do {
                                Date dogadjaj = new Date(cursor.getLong(3));
                                //Toast.makeText( KvizoviAkt.this, "Naziv: " + cursor.getString(1) + "Vrijeme početka: " + dogadjaj.toString(), Toast.LENGTH_LONG ).show();
                                long  razlikaUMinutama2 = round(TimeUnit.MILLISECONDS.toMinutes(dogadjaj.getTime()-Calendar.getInstance().getTime().getTime()));
                                if (razlikaUMinutama2>razlikaUMinutama) razlikaUMinutama =razlikaUMinutama2; //trazimo dogadjaj koji je najvise udaljen
                            } while ( cursor.moveToNext());

                            //trazimo razliku trenutnog vremena i pocetka narednog dogadjaja
                            //razlikaUMinutama = round(TimeUnit.MILLISECONDS.toMinutes(dogadjaj.getTime()-Calendar.getInstance().getTime().getTime()));
                            if (razlikaUMinutama==0) imaDogadjajUKalendaru=false; //u slucaju da aplikacija radi treba detektovati da je prosao dogadjaj
                            //Ako ovaj query vrati true to znači da postoji barem jedan događaj u narednih Y minuta i ne smije se igrati kviz
                        }

                        //ako je pronadjen dogadjaj koji pocinje za manje od X/2 minuta kreiramo AlertDialog
                        if (imaDogadjajUKalendaru)
                        {
                            AlertDialog.Builder greskaNaziv = new AlertDialog.Builder(KvizoviAkt.this);
                            greskaNaziv.setMessage("Imate događaj u\n" +
                                    "kalendaru za: " + razlikaUMinutama + " minuta!");
                            greskaNaziv.setPositiveButton("OK", null);
                            AlertDialog Naziv = greskaNaziv.create();
                            Naziv.show();
                        }
                        else {
                            Intent dodavanje = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                            dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                            startActivity(dodavanje);
                        }
                    }

                }
            });
            gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    int pozicijaDodavanja = gridView.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja && provjeriKonekciju()) {
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                        startActivity(dodavanje);
                    } else {
                        if (provjeriKonekciju()) {
                            Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                            startActivity(dodavanje);
                        }
                        else
                        {
                            Toast.makeText(KvizoviAkt.this, "Nema internet konekcije!",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                    return true;
                }
            });
            kvizAdapter.notifyDataSetChanged();

            //kraj
        }
        else {
            //normalni layout
            final Spinner spinnerKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
            ArrayAdapter<Kategorija> dataAdapter = new ArrayAdapter<Kategorija>(this,
                    android.R.layout.simple_spinner_item, kategorije);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerKategorije.setAdapter(dataAdapter);

            //samo kvizovi iz odabrane kategorije
            ArrayList<Kviz> odabrani = parsirajKvizove(JSONParsiranje);
            for (int i = 0; i < odabrani.size(); i++)
                if (!odabrani.get(i).getKategorija().getNaziv().equals(spinnerKategorije.getSelectedItem().toString()) && !odabrani.get(i).getKategorija().getNaziv().equals("Sve"))
                   odabrani.remove(i);
                kvizovi.clear();
               kvizovi.addAll(odabrani);

            //  ArrayAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, k.getPitanja());
            final ListView mojaLista = (ListView) findViewById(R.id.lvKvizovi);

            final CustomAdapterKviz adapter = new CustomAdapterKviz(this, R.layout.lista, kopijaKvizovi);

            mojaLista.setAdapter(adapter);

            //dodjela pitanja u kviz
            //k.setPitanja(pitanja);


            mojaLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                    int pozicijaDodavanja = mojaLista.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja) { //ako klikne kratkim klikom na dodajKviz treba mu se i otvoriti DodajKvizAkt
                        if (provjeriKonekciju()) {
                            Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                            startActivity(dodavanje);
                        }
                        else
                        {
                            Toast.makeText(KvizoviAkt.this, "Nema internet konekcije!",
                                    Toast.LENGTH_LONG).show();
                        }
                    } else { //otvori IgrajKviz

                        //dodaj kalendar
                        addCalendar();

                        //nadji kalendar
                        final String[] EVENT_PROJECTION = new String[] {
                                CalendarContract.Calendars._ID,                           // 0
                                CalendarContract.Calendars.ACCOUNT_NAME,                  // 1
                                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,         // 2
                                CalendarContract.Calendars.OWNER_ACCOUNT                  // 3
                        };

// The indices for the projection array above.
                         final int PROJECTION_ID_INDEX = 0;
                         final int PROJECTION_ACCOUNT_NAME_INDEX = 1;
                          final int PROJECTION_DISPLAY_NAME_INDEX = 2;
                         final int PROJECTION_OWNER_ACCOUNT_INDEX = 3;
                        Cursor cur = null;
                        ContentResolver cr = getContentResolver();
                        Uri uri = CalendarContract.Calendars.CONTENT_URI;
                        String selection = "((" + CalendarContract.Calendars.ACCOUNT_NAME + " = ?) AND ("
                                + CalendarContract.Calendars.ACCOUNT_TYPE + " = ?) AND ("
                                + CalendarContract.Calendars.OWNER_ACCOUNT + " = ?))";
                        String[] selectionArgs = new String[] {"test@test.ba", "test.test.ba",
                                "test@test.ba"};
// Submit the query and get a Cursor object back.
                        cur = cr.query(uri, EVENT_PROJECTION, selection, selectionArgs, null);
                        long idKalendara = 0;
                        //pretrazujemo povratni kursor
                        while (cur.moveToNext()) {
                            idKalendara = cur.getLong(PROJECTION_ID_INDEX);

                        }
                        //precistimo kvizove za svaki slucaj
                        Kviz k = kvizovi.get(position);
                        for (int i = 0; i < k.getPitanja().size(); i++)
                            if (k.getPitanja().get(i).getNaziv().equals("Dodaj Pitanje")) k.getPitanja().remove(i);
                            //racunamo X shodno postavci
                            int X = round (k.getPitanja().size()/2);
                        //kreiramo novi dogadjaj (za testiranje, TODO: ODKOMENTIRATI AKO TREBA TESTIRATI OVU FUNKCIONALNOST!)

                        //kreirajDogadjaj(idKalendara);

                        //provjeravamo je li postoji li dogadjaj u narednih X minuta
                        ContentResolver contentResolver = KvizoviAkt.this.getContentResolver();
                        String[] projection = new String[] { CalendarContract.Events.CALENDAR_ID, CalendarContract.Events.TITLE, CalendarContract.Events.DESCRIPTION, CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND, CalendarContract.Events.ALL_DAY, CalendarContract.Events.EVENT_LOCATION };
                        // Create a cursor and read from the calendar (for Android API below 4.0)
                        Calendar startTime = Calendar.getInstance();
                        Calendar endTime = Calendar.getInstance();
                        endTime.add(Calendar.MINUTE, X);
                        String selection2 = "(( " + CalendarContract.Events.DTSTART + " >= " + startTime.getTimeInMillis() + " ) AND ( " + CalendarContract.Events.DTSTART + " <= " + endTime.getTimeInMillis() + " ))";

                        long razlikaUMinutama=0;
                        boolean imaDogadjajUKalendaru=false;
                        Cursor cursor = contentResolver.query( CalendarContract.Events.CONTENT_URI, projection, selection2, null, null );
                        if (cursor.moveToFirst())
                        {
                            imaDogadjajUKalendaru=true;
                            do {
                                Date dogadjaj = new Date(cursor.getLong(3));
                                //Toast.makeText( KvizoviAkt.this, "Naziv: " + cursor.getString(1) + "Vrijeme početka: " + dogadjaj.toString(), Toast.LENGTH_LONG ).show();
                                long  razlikaUMinutama2 = round(TimeUnit.MILLISECONDS.toMinutes(dogadjaj.getTime()-Calendar.getInstance().getTime().getTime()));
                                if (razlikaUMinutama2>razlikaUMinutama) razlikaUMinutama =razlikaUMinutama2; //trazimo dogadjaj koji je najvise udaljen
                            } while ( cursor.moveToNext());

                            //trazimo razliku trenutnog vremena i pocetka narednog dogadjaja
                            //razlikaUMinutama = round(TimeUnit.MILLISECONDS.toMinutes(dogadjaj.getTime()-Calendar.getInstance().getTime().getTime()));
                            if (razlikaUMinutama==0) imaDogadjajUKalendaru=false; //u slucaju da aplikacija radi treba detektovati da je prosao dogadjaj
                            //Ako ovaj query vrati true to znači da postoji barem jedan događaj u narednih Y minuta i ne smije se igrati kviz
                        }

                        //ako je pronadjen dogadjaj koji pocinje za manje od X/2 minuta kreiramo AlertDialog
                        if (imaDogadjajUKalendaru)
                        {
                            AlertDialog.Builder greskaNaziv = new AlertDialog.Builder(KvizoviAkt.this);
                            greskaNaziv.setMessage("Imate događaj u\n" +
                                    "kalendaru za: " + razlikaUMinutama + " minuta!");
                            greskaNaziv.setPositiveButton("OK", null);
                            AlertDialog Naziv = greskaNaziv.create();
                            Naziv.show();
                        }
                        else {
                            Intent dodavanje = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                            dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                            startActivity(dodavanje);
                        }
                    }

                }
            });
            mojaLista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    int pozicijaDodavanja = mojaLista.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja && provjeriKonekciju()) {
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                        startActivity(dodavanje);
                    } else if (provjeriKonekciju()){
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                        startActivity(dodavanje);
                    }
                    else
                    {
                        Toast.makeText(KvizoviAkt.this, "Nema internet konekcije!",
                                Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
            });
            //filter po kategorijama
            spinnerKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterac, View view, int position, long arg) {
                    //CustomAdapterPitanje adapter = new CustomAdapterPitanje(this, R.layout.lista, pitanja);
                    if (prviPutUcitan) prviPutUcitan = false;
                    if (!prviPutUcitan) {
                        int pozicijaDodavanja = spinnerKategorije.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                        kopijaKvizovi.clear();
                        for (int i = 0; i < kvizovi.size(); i++) {
                            if (kvizovi.get(i).getKategorija().getNaziv().equals(spinnerKategorije.getSelectedItem().toString()))
                                kopijaKvizovi.add(kvizovi.get(i));
                        }
                        boolean ima = false;
                        //brise i element za dodavanje pa treba pripaziti
                        for (int i = 0; i < kopijaKvizovi.size(); i++)
                            if (kopijaKvizovi.get(i).getNaziv().equals("Dodaj Kviz")) ima = true;
                        if (!ima)
                            kopijaKvizovi.add(new Kviz("Dodaj Kviz", android.R.drawable.ic_input_add));
                        adapter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parentView) {
                    boolean ima = false;
                    for (int i = 0; i < kopijaKvizovi.size(); i++)
                        if (kopijaKvizovi.get(i).getNaziv().equals("Dodaj Kviz")) ima = true;
                    if (!ima)
                        kopijaKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
                    adapter.notifyDataSetChanged();
                }
            });
        }
        if (provjeriKonekciju()) {
            new KreirajDokumentTask().execute("proba");
        }
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle bundle = new Bundle();
        bundle.putSerializable("Kviz", kvizovi);
        bundle.putSerializable("Kategorije", kategorije);
        bundle.putSerializable("Pitanja", pitanja);
        outState.putAll(bundle);
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        kvizovi=(ArrayList<Kviz>) savedInstanceState.getSerializable("Kviz");
        kategorije=(ArrayList<Kategorija>) savedInstanceState.getSerializable("Kategorije");
        pitanja=(ArrayList<Pitanje>) savedInstanceState.getSerializable("Pitanja");

    }
    public void addCalendar() {

        ContentValues contentValues = new ContentValues();
        contentValues.put(CalendarContract.Calendars.ACCOUNT_NAME, "test@test.ba");
        contentValues.put(CalendarContract.Calendars.ACCOUNT_TYPE, "test.test.ba");
        contentValues.put(CalendarContract.Calendars.NAME, "Test Calendar");
        contentValues.put(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME, "Test Calendar");
        contentValues.put(CalendarContract.Calendars.CALENDAR_COLOR, "232323");
        contentValues.put(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.CAL_ACCESS_OWNER);
        contentValues.put(CalendarContract.Calendars.OWNER_ACCOUNT, "test@test.ba");
        contentValues.put(CalendarContract.Calendars.ALLOWED_REMINDERS, "METHOD_ALERT, METHOD_EMAIL, METHOD_ALARM");
        contentValues.put(CalendarContract.Calendars.ALLOWED_ATTENDEE_TYPES, "TYPE_OPTIONAL, TYPE_REQUIRED, TYPE_RESOURCE");
        contentValues.put(CalendarContract.Calendars.ALLOWED_AVAILABILITY, "AVAILABILITY_BUSY, AVAILABILITY_FREE, AVAILABILITY_TENTATIVE");

        
        Uri uri = CalendarContract.Calendars.CONTENT_URI;
        uri = uri.buildUpon().appendQueryParameter(android.provider.CalendarContract.CALLER_IS_SYNCADAPTER,"true")
                .appendQueryParameter(CalendarContract.Calendars.ACCOUNT_NAME, "test@test.ba")
                .appendQueryParameter(CalendarContract.Calendars.ACCOUNT_TYPE, "test.test.ba").build();
        getContentResolver().insert(uri, contentValues);
    }
    public void kreirajDogadjaj(long idKalendara)
    {
        long calID = idKalendara;
        long startMillis = 0;
        long endMillis = 0;
        Calendar beginTime = Calendar.getInstance();
        //testni dogadjaj pocinje za 5 minuta
        beginTime.add(Calendar.MINUTE, 5);
        startMillis = beginTime.getTimeInMillis();
        Calendar endTime = Calendar.getInstance();
        //zavrsava sa 45 minuta
        endTime.add(Calendar.MINUTE, 45);
        endMillis = endTime.getTimeInMillis();

        ContentResolver cr = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(Events.DTSTART, startMillis);
        values.put(Events.DTEND, endMillis);
        values.put(Events.TITLE, "Neki dogadaj");
        values.put(Events.DESCRIPTION, "Opis");
        values.put(Events.CALENDAR_ID, calID);
        values.put(Events.EVENT_TIMEZONE, TimeZone.getTimeZone("Germany").toString());
        Uri uri = cr.insert(Events.CONTENT_URI, values);

// get the event ID that is the last element in the Uri
        long eventID = Long.parseLong(uri.getLastPathSegment());
    }
    static int brojac = 0;
    public boolean provjeriKonekciju() {
        if (getBaseContext() == null)
            return false;

        ConnectivityManager cm =
                (ConnectivityManager) getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        }
        return false;
    }

    @Override
    public void kreiranjeDetalja()
    {

    }
    @Override
    public void dajListu()
    {

    }
    @Override
    public void azuriranjeRangliste()
    {

    }

}
