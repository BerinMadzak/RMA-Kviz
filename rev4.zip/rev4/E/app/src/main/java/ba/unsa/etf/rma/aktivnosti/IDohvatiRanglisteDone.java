package ba.unsa.etf.rma.aktivnosti;

public interface IDohvatiRanglisteDone {
    public void gotovoRangliste(String json);
}
