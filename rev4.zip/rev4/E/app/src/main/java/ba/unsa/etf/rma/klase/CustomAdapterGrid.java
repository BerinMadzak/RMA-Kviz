package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class CustomAdapterGrid extends ArrayAdapter<Kviz> {

    private final Context mContext;
    private final ArrayList<Kviz> kvizovi;
    private final int resources;
    // 1

    public CustomAdapterGrid(Context context, int res, ArrayList<Kviz> kvizovi2) {
        super(context, res, kvizovi2);
        mContext = context;
        resources = res;
        kvizovi = kvizovi2;
    }

    // 2
    @Override
    public int getCount() {
        return kvizovi.size();
    }

    // 3
    @Override
    public long getItemId(int position) {
        return 0;
    }

    // 4
    // 5
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // 1
        final Kviz kvizic = kvizovi.get(position);

        // 2
        if (convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.grid_kviz, null);
        }

        // 3
        final ImageView imageView = (ImageView)convertView.findViewById(R.id.imageview_cover_art);
        final TextView nameTextView = (TextView)convertView.findViewById(R.id.textview_book_name);
        final TextView authorTextView = (TextView)convertView.findViewById(R.id.textview_book_author);

        // 4
        imageView.setImageResource(kvizic.getSlikaKviza());
        nameTextView.setText(kvizic.getNaziv());
        int brPitanja=kvizic.getPitanja().size();
        if (brPitanja>0) brPitanja--; //ako ima dodajPitanje ne treba ga racunati
        authorTextView.setText(String.valueOf(brPitanja));
        //ikona
        if (kvizic.getKategorija().getIndikator()==0 && position!=kvizovi.size()-1)
            imageView.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_notification_overlay));
        else if (position==kvizovi.size()-1)
            imageView.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_input_add));
        else
        {
            //Toast.makeText(getContext(), ""+kvizic.getSlikaKviza(), Toast.LENGTH_SHORT).show();
            final IconHelper iconHelper = IconHelper.getInstance(getContext());
            iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                @Override
                public void onDataLoaded() {
                    // This happens on UI thread, and is guaranteed to be called.
                    imageView.setImageDrawable(iconHelper.getIcon(kvizic.getSlikaKviza()).getDrawable(mContext));
                }
            });
        }
        return convertView;
    }
}
