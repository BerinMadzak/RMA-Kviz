package ba.unsa.etf.rma.klase;

public class KalendarContentReceiver  {

}
