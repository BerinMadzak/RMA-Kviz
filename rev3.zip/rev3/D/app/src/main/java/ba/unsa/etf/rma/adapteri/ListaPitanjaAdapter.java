package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class ListaPitanjaAdapter extends BaseAdapter {

    private static LayoutInflater inflater = null;
    private ArrayList<Pitanje> data;
    public Resources res;
    private boolean dodatnoPitanje;

    public ListaPitanjaAdapter(Activity a, ArrayList<Pitanje> items, Resources resLocal, boolean dodatno) {
        data = items;
        res = resLocal;
        dodatnoPitanje = dodatno;
        inflater = (LayoutInflater)a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        if(data.size() <= 0)
            return 1;
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder {
        TextView tvNazivPitanja;
        TextView tvDodajPitanje;
        ImageView iwDodajPitanje;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;

        if(convertView == null) {
            vi = inflater.inflate(R.layout.item_pitanje, parent, false);

            holder = new ViewHolder();
            holder.tvNazivPitanja = vi.findViewById(R.id.tvNazivPitanja);
            holder.tvDodajPitanje = vi.findViewById(R.id.tvDodajPitanje);
            holder.iwDodajPitanje = vi.findViewById(R.id.iwKategorija);

            vi.setTag(holder);
        }
        else {
            holder = (ViewHolder)vi.getTag();
        }

        if(data.size() <= 0) {
            holder.tvNazivPitanja.setText("");
            holder.tvDodajPitanje.setVisibility(View.GONE);
            holder.iwDodajPitanje.setVisibility(View.GONE);
        }
        else {
            Pitanje temp = data.get(position);

            if(dodatnoPitanje) {
                if (position == data.size() - 1 && temp.getNaziv().equals("")) {
                    holder.tvNazivPitanja.setVisibility(View.GONE);
                    holder.tvDodajPitanje.setVisibility(View.VISIBLE);
                    holder.iwDodajPitanje.setVisibility(View.VISIBLE);
                } else {
                    holder.tvNazivPitanja.setVisibility(View.VISIBLE);
                    holder.tvNazivPitanja.setText(temp.getNaziv());
                    holder.tvDodajPitanje.setVisibility(View.GONE);
                    holder.iwDodajPitanje.setVisibility(View.GONE);
                }
            }
            else {
                holder.tvNazivPitanja.setVisibility(View.VISIBLE);
                holder.tvNazivPitanja.setText(temp.getNaziv());
                holder.tvDodajPitanje.setVisibility(View.GONE);
                holder.iwDodajPitanje.setVisibility(View.GONE);
            }
        }
        return vi;
    }

}
