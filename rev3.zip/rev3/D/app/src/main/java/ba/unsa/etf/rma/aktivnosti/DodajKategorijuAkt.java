package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import java.io.InputStream;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.servisi.DohvatiKategorije;
import ba.unsa.etf.rma.servisi.DohvatiKvizoveIzKategorije;
import ba.unsa.etf.rma.servisi.IndexPitanjaResultReceiver;
import ba.unsa.etf.rma.servisi.KategorijaCreate;
import ba.unsa.etf.rma.servisi.KategorijaResultReceiver;
import ba.unsa.etf.rma.servisi.PitanjeCreate;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback,
                                                                     DohvatiKategorije.OnKategorijeSearchDone,
                                                                     KategorijaResultReceiver.Receiver {

    private EditText etNaziv;
    private EditText etIkona;
    private Button btnDodajIkonu;
    private Button btnDodajKategoriju;
    private Icon[] selectedIcons;
    private String iconID;
    private ArrayList<Kategorija> sveKategorije;
    private Boolean ispravanNaziv;
    private Boolean ispravnaIkona;

    public static final String EXTRA_KATEGORIJA_DKAT_TO_DKVIZ = "novaKat_za_dka";

    private static  final String SIS_KATEGORIJE = "kategorije";
    private static  final String SIS_ET_NAZIV = "etNaziv";
    private static  final String SIS_ICON_ID = "iconID";
    private static  final String SIS_ISPRAVAN_NAZIV = "okNaziv";
    private static  final String SIS_ISPRAVNA_IKONA = "okIkona";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju);

        etNaziv = findViewById(R.id.etNaziv);
        etIkona = findViewById(R.id.etIkona);
        btnDodajIkonu = findViewById(R.id.btnDodajIkonu);
        btnDodajKategoriju = findViewById(R.id.btnDodajKategoriju);

        if(savedInstanceState != null) {
            ucitajSavedInstanceStatePodatke(savedInstanceState);
        }
        else {
            ispravanNaziv = true;
            ispravnaIkona = true;
        }

        etIkona.setInputType(InputType.TYPE_NULL);

        final IconDialog iconDialog = new IconDialog();

        btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        btnDodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputStream is = getResources().openRawResource(R.raw.secret);
                new DohvatiKategorije(is, DodajKategorijuAkt.this).execute();
            }

        });

    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        iconID = Integer.toString(icons[0].getId());
        etIkona.setText(iconID);
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString(SIS_ET_NAZIV, etNaziv.getText().toString());
        savedInstanceState.putString(SIS_ICON_ID, iconID);
        savedInstanceState.putBoolean(SIS_ISPRAVAN_NAZIV, ispravanNaziv);
        savedInstanceState.putBoolean(SIS_ISPRAVNA_IKONA, ispravnaIkona);
    }

    private void ucitajSavedInstanceStatePodatke(Bundle savedInstanceState) {
        etNaziv.setText(savedInstanceState.getString(SIS_ET_NAZIV));
        iconID = savedInstanceState.getString(SIS_ICON_ID);
        etIkona.setText(iconID);
        ispravanNaziv = savedInstanceState.getBoolean(SIS_ISPRAVAN_NAZIV);
        ispravnaIkona = savedInstanceState.getBoolean(SIS_ISPRAVNA_IKONA);
        if(!ispravanNaziv)
            etNaziv.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        if(!ispravnaIkona)
            etIkona.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
    }


    private void provjeraValidnostiUnosa() {
        ispravanNaziv = true;
        ispravnaIkona = true;
        String naziv = etNaziv.getText().toString().trim();
        if(naziv.equals(""))
            ispravanNaziv = false;
        else {
            for(int i=0; i<sveKategorije.size(); i++) {
                if (sveKategorije.get(i).getNaziv().equals(naziv))
                    ispravanNaziv = false;
            }
        }

        if(iconID == null || iconID.equals(""))
            ispravnaIkona = false;


        if(!ispravanNaziv)
            etNaziv.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        else
            etNaziv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        if(!ispravnaIkona)
            etIkona.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        else
            etIkona.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    @Override
    public void onSearchDone(ArrayList<Kategorija> dohvaceneKategorije) {
        sveKategorije = dohvaceneKategorije;

        provjeraValidnostiUnosa();

        if(ispravanNaziv && ispravnaIkona) {
            String naziv = etNaziv.getText().toString().trim();
            // pokretanje servisa za kreiranje nove kategorije
            Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, DodajKategorijuAkt.this, KategorijaCreate.class);
            servisIntent.putExtra("naziv", naziv);
            servisIntent.putExtra("ikona", iconID);

            KategorijaResultReceiver kategorijaReceiver = new KategorijaResultReceiver(new Handler());
            kategorijaReceiver.setReceiver(DodajKategorijuAkt.this);
            servisIntent.putExtra("receiver", kategorijaReceiver);
            startService(servisIntent);
        }
        else {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DodajKategorijuAkt.this);
            alertDialogBuilder.setTitle("Greska pri kreiranju kategorije");
            alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.alert_icon_red));
            alertDialogBuilder.setNeutralButton(R.string.alertButton, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alertDialogBuilder.setMessage("Unesena kategorija vec postoji!");
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
            centrirajAlertDialogButton(alertDialog);
        }
    }

    private void centrirajAlertDialogButton(AlertDialog alertDialog) {
        Button neutralButton = alertDialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        LinearLayout.LayoutParams neutralButtonLL = (LinearLayout.LayoutParams)neutralButton.getLayoutParams();
        neutralButtonLL.weight = 10;
        neutralButton.setLayoutParams(neutralButtonLL);
    }

    @Override
    public void onKategorijaReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KategorijaCreate.STATUS_RUNNING :
                break;
            case KategorijaCreate.STATUS_FINISHED :
                Intent iData = new Intent();
                iData.putExtra(EXTRA_KATEGORIJA_DKAT_TO_DKVIZ, etNaziv.getText().toString().trim());
                setResult(AppCompatActivity.RESULT_OK, iData);
                finish();
                break;
            case KategorijaCreate.STATUS_ERROR :
                String error = resultData.getString(Intent.EXTRA_TEXT);
                break;
        }
    }
}
