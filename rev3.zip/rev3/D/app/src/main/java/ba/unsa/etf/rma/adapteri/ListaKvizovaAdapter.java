package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class ListaKvizovaAdapter extends BaseAdapter {

    private Activity activity;
    private static LayoutInflater inflater = null;
    private ArrayList<Kviz> data;
    private ArrayList<Kviz> pomocni;
    private Kviz temp;
    public Resources res;
    private ViewHolder holder;

    public ListaKvizovaAdapter(Activity a, ArrayList<Kviz> items, Resources resLocal) {
        activity = a;
        data = items;
        pomocni= items;

        res = resLocal;
        inflater = (LayoutInflater)a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        if(data.size() <= 0)
            return 1;
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder {
        TextView tvNazivKviza;
        ImageView iwKategorija;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;

        if (convertView == null) {
            vi = inflater.inflate(R.layout.item_kviz, parent, false);

            holder = new ViewHolder();
            holder.tvNazivKviza = vi.findViewById(R.id.tvNazivKviza);
            holder.iwKategorija = vi.findViewById(R.id.iwKategorija);

            vi.setTag(holder);
        } else {
            holder = (ViewHolder) vi.getTag();
        }

        if (data.size() <= 0) {
            holder.tvNazivKviza.setText("");
        } else {
            temp = data.get(position);

            holder.tvNazivKviza.setText(temp.getNaziv());
            if(temp.getKategorija().getNaziv().equals(activity.getString(R.string.sviKvizovi))) {
                if(temp.getNaziv().equals(activity.getString(R.string.dodajNoviKviz)))
                    holder.iwKategorija.setImageResource(R.drawable.add_circle_green);
                else
                    holder.iwKategorija.setImageResource(R.drawable.question_mark);
                holder.iwKategorija.setColorFilter(ActivityCompat.getColor(activity, android.R.color.transparent));

            }
            else {
                final IconHelper iconHelper = IconHelper.getInstance(activity);
                iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                    @Override
                    public void onDataLoaded() {
                        // This happens on UI thread, and is guaranteed to be called.
                        holder.iwKategorija.setImageDrawable(iconHelper.getIcon(Integer.parseInt(temp.getKategorija().getId())).getDrawable(activity));
                        holder.iwKategorija.setColorFilter(ActivityCompat.getColor(activity, android.R.color.holo_orange_dark));
                    }
                });

            }
        }

        return vi;
    }

    public void filter(String kategorija) {
        data = new ArrayList<>();
        if (kategorija.equals(activity.getString(R.string.sviKvizovi))) {
           data.addAll(pomocni);
        }
        else
        {
            for (Kviz k : pomocni)
            {
                if (k.getKategorija().getNaziv().equals(kategorija))
                {
                    data.add(k);
                }
            }
            data.add(pomocni.get(pomocni.size() - 1));
        }
        notifyDataSetChanged();
    }

}


