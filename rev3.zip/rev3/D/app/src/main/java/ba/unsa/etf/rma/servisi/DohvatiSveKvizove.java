package ba.unsa.etf.rma.servisi;

import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DohvatiSveKvizove extends AsyncTask<Void, Integer, Void> {

    private InputStream is;
    private ArrayList<Kviz> kvizovi;
    private ArrayList<Kategorija> kategorije;
    private OnKvizoviSearchDone pozivatelj;
    private String TOKEN;
    private ArrayList<String> idKategorija;

    public DohvatiSveKvizove(InputStream inStream, OnKvizoviSearchDone p) {
        is = inStream;
        pozivatelj = p;
    }
    @Override
    protected Void doInBackground(Void...voids) {

        kvizovi = new ArrayList<>();
        kategorije = new ArrayList<>();
        idKategorija = new ArrayList<>();

        GoogleCredential credentials;
        try {
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        String projektID = "rma19-568b8";

        dohvatiKategorije(projektID);

        dohvatiKvizove(projektID);

        return null;
    }


    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pozivatelj.onSviKvizoviDone(kvizovi, kategorije);
    }

    private String convertStreamToString(InputStream iStream) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(iStream));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                iStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public interface OnKvizoviSearchDone {
        void onSviKvizoviDone(ArrayList<Kviz> dohvaceniKvizovi, ArrayList<Kategorija> dohvaceneKategorije);
    }

    private void dohvatiKategorije(String projektID) {
        try {
            //dohvatanje svih kategorija
            String urlKategorije = "https://firestore.googleapis.com/v1/projects/" + projektID +
                    "/databases/(default)/documents/Kategorije?pageSize=500&access_token=" + TOKEN;
            URL url = new URL(urlKategorije);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            InputStream  in = new BufferedInputStream(urlConnection.getInputStream());
            String dobavljeneKategorije= convertStreamToString(in);

            JSONObject joKategorije = new JSONObject(dobavljeneKategorije);
            JSONArray kategorijaDocuments = joKategorije.optJSONArray("documents");

            if(kategorijaDocuments != null) {
                for (int l = 0; l < kategorijaDocuments.length(); l++) {
                    JSONObject katDocument = kategorijaDocuments.getJSONObject(l);
                    JSONObject katFields = katDocument.getJSONObject("fields");

                    JSONObject katNaziv = katFields.getJSONObject("naziv");
                    String nazivKategorije = katNaziv.getString("stringValue");

                    JSONObject katIkonica = katFields.getJSONObject("idIkonice");
                    int ikonicaID = katIkonica.getInt("integerValue");

                    //izdvajanje IDeva kategorija
                    String katPath = katDocument.getString("name");
                    String[] katPathFields = katPath.split("/");
                    idKategorija.add(katPathFields[katPathFields.length - 1]);

                    kategorije.add(new Kategorija(nazivKategorije, Integer.toString(ikonicaID)));
                }
            }
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void dohvatiKvizove(String projektID) {
        ArrayList<Pitanje> pitanjaKviza;
        try {
            //dohvatanje kvizova
            String urlQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents/Kvizovi" +
                    "?pageSize=500&access_token=" + TOKEN;

            URL url = new URL(urlQuery);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String dobavljeniKvizovi= convertStreamToString(in);

            JSONObject joKvizovi = new JSONObject(dobavljeniKvizovi);
            JSONArray kvizDocuments = joKvizovi.optJSONArray("documents");

            if(kvizDocuments != null) {
                for (int i = 0; i < kvizDocuments.length(); i++) {
                    JSONObject document = kvizDocuments.getJSONObject(i);

                    String kvizPath = document.getString("name");
                    String[] kvizPathFields = kvizPath.split("/");
                    String kvizID = kvizPathFields[kvizPathFields.length - 1];

                    JSONObject fields = document.getJSONObject("fields");

                    JSONObject joNaziv = fields.getJSONObject("naziv");
                    String nazivKviza = joNaziv.getString("stringValue");

                    // query za dohvatanje pitanja i-tog kviza
                    JSONObject joPitanja = fields.getJSONObject("pitanja");
                    JSONObject arrayValue = joPitanja.getJSONObject("arrayValue");
                    JSONArray values = arrayValue.optJSONArray("values");
                    if (values == null) values = new JSONArray();
                    pitanjaKviza = new ArrayList<>();
                    for (int j = 0; j < values.length(); j++) {
                        JSONObject valueItem = values.getJSONObject(j);
                        String pitanjeQuery = "https://firestore.googleapis.com/v1/projects/" + projektID +
                                "/databases/(default)/documents/Pitanja/" + valueItem.getString("stringValue") +
                                "?access_token=" + TOKEN;
                        URL url3 = new URL(pitanjeQuery);
                        HttpURLConnection urlConnection3 = (HttpURLConnection) url3.openConnection();
                        in = new BufferedInputStream(urlConnection3.getInputStream());
                        String dobavljenoPitanje = convertStreamToString(in);

                        Pitanje pitanje = new Pitanje();
                        JSONObject pitanjeDocument = new JSONObject(dobavljenoPitanje);
                        JSONObject pitanjeFields = pitanjeDocument.getJSONObject("fields");
                        JSONObject nazivPitanja = pitanjeFields.getJSONObject("naziv");
                        pitanje.setNaziv(nazivPitanja.getString("stringValue"));
                        pitanje.setTekstPitanja(nazivPitanja.getString("stringValue"));

                        JSONObject odgovoriPitanja = pitanjeFields.getJSONObject("odgovori");
                        JSONObject arrayValueOdgovori = odgovoriPitanja.getJSONObject("arrayValue");
                        JSONArray valuesOdgovori = arrayValueOdgovori.getJSONArray("values");

                        for (int k = 0; k < valuesOdgovori.length(); k++) {
                            JSONObject odgovorItem = valuesOdgovori.getJSONObject(k);
                            pitanje.getOdgovori().add(odgovorItem.getString("stringValue"));
                        }

                        JSONObject indexTacnog = pitanjeFields.getJSONObject("indexTacnog");
                        pitanje.setTacan(pitanje.getOdgovori().get(indexTacnog.getInt("integerValue")));
                        pitanjaKviza.add(pitanje);
                    }

                    JSONObject idKat = fields.getJSONObject("idKategorije");
                    String idKategorije = idKat.getString("stringValue");

                    for (int f = 0; f < idKategorija.size(); f++) {
                        if (idKategorija.get(f).equals(idKategorije)) {
                            Kviz tempKviz = new Kviz(nazivKviza, pitanjaKviza, kategorije.get(f));
                            tempKviz.setFirestoreID(kvizID);
                            kvizovi.add(tempKviz);
                            break;
                        }
                    }
                }
            }

        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}
