package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.renderscript.ScriptGroup;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;


public class KvizCreate extends IntentService {

    private String TOKEN;
    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public KvizCreate() {
        super("KvizCreate");
    }

    public KvizCreate(String name) {
        super(name);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver receiver = intent.getParcelableExtra("receiver");
        Bundle bundle = new Bundle();
        receiver.send(STATUS_RUNNING, Bundle.EMPTY);

        String nazivKviza = intent.getStringExtra("naziv");
        String nazivKategorije = intent.getStringExtra("kategorija");
        ArrayList<String> idPitanja = intent.getStringArrayListExtra("pitanja");

        InputStream is = getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials;
        TOKEN = null;
        try {
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String projektID = "rma19-568b8";

        String idKategorije = dohvatiIdKategorije(projektID, nazivKategorije);

        kreirajKviz(projektID, idKategorije, nazivKviza, idPitanja);

        kreirajRangListu(projektID, nazivKviza);

        receiver.send(STATUS_FINISHED, bundle);
    }

    private String convertStreamToString(InputStream iStream) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(iStream));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                iStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    private String dohvatiIdKategorije(String projektID, String nazivKategorije) {
        //nalazenje id kategorije prema nazivu
        String urlQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents:runQuery";
        String idKategorije = "";
        String kategorijaQuery =
                "{" +
                        "\"structuredQuery\" : {" +
                        "\"from\" : [{\"collectionId\" : \"Kategorije\"}]," +
                        "\"where\" : {" +
                        "\"fieldFilter\" : {" +
                        "\"field\" : {" +
                        "\"fieldPath\" : \"naziv\"" +
                        "}," +
                        "\"op\" : \"EQUAL\"," +
                        "\"value\" : {" +
                        "\"stringValue\" : \"" + nazivKategorije + "\"" +
                        "}" +
                        "}" +
                        "}" +
                        "}" +
                        "}";
        try {
            URL url = new URL(urlQuery);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json; UTF-8");
            urlConnection.setRequestProperty("Accept", "application/json");
            urlConnection.setRequestProperty("Authorization", "Bearer " + TOKEN);

            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = kategorijaQuery.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            String dobavljenaKategorija = convertStreamToString(in);
            JSONArray katDocuments = new JSONArray(dobavljenaKategorija);
            JSONObject katDocument = katDocuments.getJSONObject(0);
            JSONObject document = katDocument.getJSONObject("document");
            String katName = document.getString("name");
            String[] pathFields = katName.split("/");
            idKategorije = pathFields[pathFields.length - 1];
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return idKategorije;
    }

    private void kreirajKviz(String projektID, String idKategorije, String nazivKviza, ArrayList<String> idPitanja) {
        try {
            StringBuilder createBuilder = new StringBuilder();
            createBuilder
                    .append("{")
                    .append("\"fields\" : {")
                    .append("\"naziv\" : {")
                    .append("\"stringValue\" : \"").append(nazivKviza).append("\"")
                    .append("},")
                    .append("\"idKategorije\" : {")
                    .append("\"stringValue\" : \"").append(idKategorije).append("\"")
                    .append("},")
                    .append("\"pitanja\" : {")
                    .append("\"arrayValue\" : {")
                    .append("\"values\" : [");
            for(int i = 0; i<idPitanja.size() - 1; i++) {
                createBuilder.append("{\"stringValue\": \"")
                        .append(idPitanja.get(i))
                        .append("\"},");
            }
            if(idPitanja.size()!=0) {
                createBuilder.append("{\"stringValue\": \"")
                        .append(idPitanja.get(idPitanja.size() - 1))
                        .append("\"}");
            }
            createBuilder.append("]")
                    .append("}")
                    .append("}")
                    .append("}")
                    .append("}");

            String createQuery = createBuilder.toString();

            String urlQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents/Kvizovi";

            URL url = new URL(urlQuery);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json; UTF-8");
            urlConnection.setRequestProperty("Accept", "application/json");
            urlConnection.setRequestProperty("Authorization", "Bearer " + TOKEN);

            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = createQuery.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            String kreiraniKviz = convertStreamToString(in);
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void kreirajRangListu(String projektID, String nazivKviza) {
        try {
            //pri kreiranju kviza na firestoreu potrebno kreirati i odgovarajuci dokument u RangListe kolekciji
            String rangListQuery =
                    "{" +
                            "\"fields\" : {" +
                            "\"nazivKviza\" : {" +
                            "\"stringValue\" : \"" + nazivKviza + "\"" +
                            "}," +
                            "\"lista\" : {" +
                            "\"mapValue\" : {" +
                            "\"fields\" : {" +
                            "}" +
                            "}" +
                            "}" +
                            "}" +
                            "}";


            String urlQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents/Rangliste";

            URL url = new URL(urlQuery);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json; UTF-8");
            urlConnection.setRequestProperty("Accept", "application/json");
            urlConnection.setRequestProperty("Authorization", "Bearer " + TOKEN);

            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = rangListQuery.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            String kreiranaRangLista = convertStreamToString(in);

        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
