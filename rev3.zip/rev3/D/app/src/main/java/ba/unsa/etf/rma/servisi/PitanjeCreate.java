package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;


public class PitanjeCreate extends IntentService {

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public PitanjeCreate() {
        super("PitanjeCreate");
    }

    public PitanjeCreate(String name) {
        super(name);
    }
    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver receiver = intent.getParcelableExtra("receiver");
        Bundle bundle = new Bundle();

        receiver.send(STATUS_RUNNING, Bundle.EMPTY);

        String naziv = intent.getStringExtra("naziv");
        ArrayList<String> odgovori = intent.getStringArrayListExtra("odgovori");
        int indexTacnog = intent.getIntExtra("tacan", 0);

        InputStream is = getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials;
        String TOKEN = null;
        try {
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        String projektID = "rma19-568b8";

        String urlQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents/Pitanja";

        StringBuilder createBuilder = new StringBuilder();
        createBuilder
                .append("{")
                    .append("\"fields\" : {")
                        .append("\"naziv\" : {")
                            .append("\"stringValue\" : \"").append(naziv).append("\"")
                        .append("},")
                        .append("\"indexTacnog\" : {")
                            .append("\"integerValue\" : ").append(Integer.toString(indexTacnog))
                        .append("},")
                        .append("\"odgovori\" : {")
                            .append("\"arrayValue\" : {")
                                .append("\"values\" : [");
                                    for(int i = 0; i<odgovori.size() - 1; i++) {
                                        createBuilder.append("{\"stringValue\": \"")
                                                .append(odgovori.get(i))
                                                .append("\"},");
                                    }
                                    createBuilder.append("{\"stringValue\": \"")
                                        .append(odgovori.get(odgovori.size() - 1))
                                        .append("\"}")
                                .append("]")
                            .append("}")
                        .append("}")
                    .append("}")
                .append("}");

        String createQuery = createBuilder.toString();

        try {
            URL url = new URL(urlQuery);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json; UTF-8");
            urlConnection.setRequestProperty("Accept", "application/json");
            urlConnection.setRequestProperty("Authorization", "Bearer " + TOKEN);

            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = createQuery.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            String kreiranoPitanje = convertStreamToString(in);

            JSONObject joPitanje = new JSONObject(kreiranoPitanje);
            String path = joPitanje.getString("name");
            String[] pathFields = path.split("/");

            bundle.putString("id", pathFields[pathFields.length - 1]);
            receiver.send(STATUS_FINISHED, bundle);
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
            bundle.putString(Intent.EXTRA_TEXT, e.toString());
            receiver.send(STATUS_ERROR, bundle);
        }
        catch (IOException e) {
            e.printStackTrace();
            bundle.putString(Intent.EXTRA_TEXT, e.toString());
            receiver.send(STATUS_ERROR, bundle);
        }
        catch (Exception e) {
            e.printStackTrace();
            bundle.putString(Intent.EXTRA_TEXT, e.toString());
            receiver.send(STATUS_ERROR, bundle);
        }
    }

    private String convertStreamToString(InputStream iStream) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(iStream));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                iStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
