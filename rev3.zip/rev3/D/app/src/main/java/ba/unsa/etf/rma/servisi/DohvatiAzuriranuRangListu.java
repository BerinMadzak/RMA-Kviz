package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.support.v4.util.Pair;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Locale;

import ba.unsa.etf.rma.R;


public class DohvatiAzuriranuRangListu extends IntentService {

    ArrayList<Pair<String, Double>> rangLista;
    ArrayList<String> formatiranaLista;

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public DohvatiAzuriranuRangListu() {
        super("DohvatiAzuriranuRangListu");
    }

    public DohvatiAzuriranuRangListu(String name) {
        super(name);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver receiver = intent.getParcelableExtra("receiver");
        Bundle bundle = new Bundle();

        receiver.send(STATUS_RUNNING, Bundle.EMPTY);

        String imeIgraca = intent.getStringExtra("ime");
        String nazivKviza = intent.getStringExtra("kviz");
        double procent = intent.getDoubleExtra("procent", 0);

        rangLista = new ArrayList<>();
        formatiranaLista = new ArrayList<>();

        String projektID = "rma19-568b8";

        String idRangListe = dohvatiTrenutnuRangListu(nazivKviza, projektID);

        //dodavanje novog imena ukoliko je uneseno i sortiranje

        if (!imeIgraca.equals("")) {
            rangLista.add(Pair.create(imeIgraca, procent));

            Collections.sort(rangLista, new Comparator<Pair<String, Double>>() {
                @Override
                public int compare(Pair<String, Double> o1, Pair<String, Double> o2) {
                    return o2.second.compareTo(o1.second);
                }
            });

            //formatirana lista za popunjavanje listviewa
            for (int i = 0; i < rangLista.size(); i++)
                formatiranaLista.add(Integer.toString(i + 1) + ".   " + rangLista.get(i).first + "   " + String.format(Locale.US, "%.2f %%", rangLista.get(i).second));

            //kreiranje patcha rang liste sa novom sortiranom listom
            kreirajPatchListe(projektID, idRangListe);
        }
        else {
            Collections.sort(rangLista, new Comparator<Pair<String, Double>>() {
                    @Override
                    public int compare(Pair<String, Double> o1, Pair<String, Double> o2) {
                        return o2.second.compareTo(o1.second);
                    }
            });

            //kreiranje formatiraneListe na osnovu rangListe
            for (int i = 0; i < rangLista.size(); i++) {
                formatiranaLista.add(Integer.toString(i + 1) + ".   " + rangLista.get(i).first + "   " + String.format(Locale.US, "%.2f %%", rangLista.get(i).second));
            }
        }

        bundle.putStringArrayList("rangLista", formatiranaLista);
        receiver.send(STATUS_FINISHED, bundle);
    }

    private String convertStreamToString(InputStream iStream) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(iStream));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                iStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    private String getToken() {
        InputStream is = getResources().openRawResource(R.raw.secret);
        GoogleCredential credentials;
        String TOKEN = null;
        try {
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return TOKEN;
    }


    private String dohvatiTrenutnuRangListu(String nazivKviza, String projektID) {
        String TOKEN = getToken();
        String urlQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents:runQuery";
        String idRangListe = "";
        try {
            //dohvatanje rang liste sa proslijedjenim nazivom kviza
            String rangListQuery =
                    "{" +
                            "\"structuredQuery\" : {" +
                            "\"from\" : [{\"collectionId\" : \"Rangliste\"}]," +
                            "\"where\" : {" +
                            "\"fieldFilter\" : {" +
                            "\"field\" : {" +
                            "\"fieldPath\" : \"nazivKviza\"" +
                            "}," +
                            "\"op\" : \"EQUAL\"," +
                            "\"value\" : {" +
                            "\"stringValue\" : \"" + nazivKviza + "\"" +
                            "}" +
                            "}" +
                            "}" +
                            "}" +
                            "}";


            URL url = new URL(urlQuery);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json; UTF-8");
            urlConnection.setRequestProperty("Accept", "application/json");
            urlConnection.setRequestProperty("Authorization", "Bearer " + TOKEN);

            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = rangListQuery.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            String dobavljenaLista = convertStreamToString(in);
            JSONArray listaDocuments = new JSONArray(dobavljenaLista);
            JSONObject listDocument = listaDocuments.getJSONObject(0);
            JSONObject document = listDocument.getJSONObject("document");
            String listName = document.getString("name");
            String[] pathFields = listName.split("/");
            idRangListe = pathFields[pathFields.length - 1];

            //dodavanje vrijednosti parova u atribut rangLista
            JSONObject fields = document.getJSONObject("fields");
            JSONObject lista = fields.getJSONObject("lista");
            JSONObject mapValue = lista.getJSONObject("mapValue");

            //polje fields nece postojati ako je prvi unos imena igraca kviza
            if (mapValue.has("fields")) {
                JSONObject mapFields = mapValue.getJSONObject("fields");

                Iterator<String> keys = mapFields.keys();
                while (keys.hasNext()) {
                    JSONObject pozicijaListe = mapFields.getJSONObject(keys.next());
                    JSONObject pozicijaMapValue = pozicijaListe.getJSONObject("mapValue");
                    JSONObject pozicijaFields = pozicijaMapValue.getJSONObject("fields");

                    Iterator<String> pozicijaKeys = pozicijaFields.keys();
                    String igracNaPoziciji = pozicijaKeys.next();
                    JSONObject procentObject = pozicijaFields.getJSONObject(igracNaPoziciji);
                    double procentNaPoziciji = procentObject.getDouble("doubleValue");

                    rangLista.add(Pair.create(igracNaPoziciji, procentNaPoziciji));
                }
            }
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return idRangListe;
    }

    private void kreirajPatchListe(String projektID, String idRangListe) {
        String urlQuery = "https://firestore.googleapis.com/v1/projects/" + projektID + "/databases/(default)/documents/Rangliste/" +
                idRangListe + "?updateMask.fieldPaths=lista";

        String TOKEN = getToken();
        try {
            StringBuilder patchBuilder = new StringBuilder();
            patchBuilder
                    .append("{")
                    .append("\"fields\" : {")
                    .append("\"lista\" : {")
                    .append("\"mapValue\" : {")
                    .append("\"fields\" : {");
            for (int i = 0; i < rangLista.size() - 1; i++) {
                patchBuilder.append("\"").append(Integer.toString(i)).append("\": {");
                patchBuilder.append("\"mapValue\": {");
                patchBuilder.append("\"fields\": {");
                patchBuilder.append("\"").append(rangLista.get(i).first).append("\": {");
                patchBuilder.append("\"doubleValue\": ").append(String.format(Locale.US, "%.2f", rangLista.get(i).second));
                patchBuilder.append("}");
                patchBuilder.append("}");
                patchBuilder.append("}");
                patchBuilder.append("},");
            }
            patchBuilder.append("\"").append(Integer.toString(rangLista.size() - 1)).append("\": {");
            patchBuilder.append("\"mapValue\": {");
            patchBuilder.append("\"fields\": {");
            patchBuilder.append("\"").append(rangLista.get(rangLista.size() - 1).first).append("\": {");
            patchBuilder.append("\"doubleValue\": ").append(String.format(Locale.US, "%.2f", rangLista.get(rangLista.size() - 1).second));
            patchBuilder.append("}");
            patchBuilder.append("}");
            patchBuilder.append("}");
            patchBuilder.append("}")
                    .append("}")
                    .append("}")
                    .append("}")
                    .append("}")
                    .append("}");

            String patchLista = patchBuilder.toString();

            URL url = new URL(urlQuery);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("PATCH");
            urlConnection.setRequestProperty("Content-Type", "application/json; UTF-8");
            urlConnection.setRequestProperty("Accept", "application/json");
            urlConnection.setRequestProperty("Authorization", "Bearer " + TOKEN);

            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = patchLista.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            String azuriranaLista = convertStreamToString(in);
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
