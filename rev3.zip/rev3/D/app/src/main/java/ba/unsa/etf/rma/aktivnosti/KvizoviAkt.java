package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;

import ba.unsa.etf.rma.adapteri.ListaKvizovaAdapter;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.adapteri.SpinnerKategorijaAdapter;
import ba.unsa.etf.rma.servisi.DohvatiKvizoveIntentServis;
import ba.unsa.etf.rma.servisi.DohvatiKvizoveIzKategorije;
import ba.unsa.etf.rma.servisi.DohvatiSveKvizove;
import ba.unsa.etf.rma.servisi.KvizoviResultReceiver;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.Listener,
                                                             DetailFrag.Listener,
                                                             DohvatiKvizoveIzKategorije.OnKvizSearchDone,
                                                             KvizoviResultReceiver.Receiver,
                                                             DohvatiSveKvizove.OnKvizoviSearchDone {

    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;
    private ArrayList<Kviz> kvizovi;
    private ArrayList<Kategorija> kategorije;
    private ListaKvizovaAdapter kvizoviAdapter;
    private SpinnerKategorijaAdapter spinnerAdapter;
    private DetailFrag df;
    private ListaFrag lf;
    private int pozicijaSpinner;

    public static final int QUIZ_REQUEST_CODE = 123;

    public static final String EXTRA_KVIZ_TO_IGRAJKVIZ = "kviz_to_igraj";
    public static final String EXTRA_KATEGORIJA_TO_LISTA_FRAG = "kat_to_lf";
    public static final String EXTRA_KVIZOVI_TO_DETAIL_FRAG = "kviz_to_df";
    public static final String EXTRA_FILTER_TO_DETAIL_FRAG = "filter_to_df";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi);

        spPostojeceKategorije = findViewById(R.id.spPostojeceKategorije);
        lvKvizovi = findViewById(R.id.lvKvizovi);

        FrameLayout lp = findViewById(R.id.listPlace);
        if(lp == null) {
            spPostojeceKategorije.setVisibility(View.INVISIBLE);
            lvKvizovi.setVisibility(View.INVISIBLE);
        }

        kvizovi = new ArrayList<>();
        kategorije = new ArrayList<>();


        Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, KvizoviAkt.this, DohvatiKvizoveIntentServis.class);

        KvizoviResultReceiver mReceiver = new KvizoviResultReceiver(new Handler());
        mReceiver.setReceiver(KvizoviAkt.this);
        servisIntent.putExtra("receiver", mReceiver);
        startService(servisIntent);

    }

    private void pokreniDodajKvizAkt(String id) {
        Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
        intent.putExtra("id", id);
        startActivityForResult(intent, QUIZ_REQUEST_CODE);
    }

    private void pokreniIgrajKvizAkt(String naziv) {
        if (!naziv.equals(getString(R.string.dodajNoviKviz))) {
            Intent intent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
            for (int i = 0; i < kvizovi.size(); i++)
                if (kvizovi.get(i).getNaziv().equals(naziv)) {
                    intent.putExtra(EXTRA_KVIZ_TO_IGRAJKVIZ, kvizovi.get(i));
                    break;
                }
            startActivity(intent);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent pData) {
        if (requestCode == QUIZ_REQUEST_CODE )
        {
            if (resultCode == AppCompatActivity.RESULT_OK)
            {
                InputStream is = getResources().openRawResource(R.raw.secret);
                new DohvatiSveKvizove(is, KvizoviAkt.this).execute();
            }
        }
    }

    @Override
    public void itemClicked(String kategorija, int pozicija) {
        pozicijaSpinner = pozicija;

        if(!kategorija.equals("Svi")) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            new DohvatiKvizoveIzKategorije(is, KvizoviAkt.this).execute(kategorija);
        }
        else {
            InputStream is = getResources().openRawResource(R.raw.secret);
            new DohvatiSveKvizove(is, KvizoviAkt.this).execute();
        }
    }

    @Override
    public void gridItemClicked(String naziv) {
        pokreniIgrajKvizAkt(naziv);
    }

    @Override
    public void gridItemLongClicked(String naziv) {
        pokreniDodajKvizAkt(naziv);
    }

    @Override
    public void onDone(ArrayList<Kviz> dohvaceniKvizovi, ArrayList<Kategorija> dohvaceneKategorije) {

        //ako se razlikuju velicine znaci da je u medjuvremenu dodato jos kategorija
        if(dohvaceneKategorije.size()!=kategorije.size()-1) {
            String trenutnaKategorija = kategorije.get(pozicijaSpinner).getNaziv();
            kategorije = dohvaceneKategorije;
            kategorije.add(new Kategorija(getString(R.string.sviKvizovi), Integer.toString(R.drawable.question_mark)));
            for(int i = 0; i < kategorije.size(); i++) {
                if(kategorije.get(i).getNaziv().equals(trenutnaKategorija)) {
                    pozicijaSpinner = i;
                    break;
                }
            }
            FrameLayout lp = findViewById(R.id.listPlace);
            if(lp == null) {
                spinnerAdapter = new SpinnerKategorijaAdapter(this, kategorije, getResources(), false);
                spPostojeceKategorije.setAdapter(spinnerAdapter);
                spPostojeceKategorije.setSelection(pozicijaSpinner);
                ProgressBar pb = findViewById(R.id.loadingPanel);
                pb.setVisibility(View.GONE);
                spPostojeceKategorije.setVisibility(View.VISIBLE);
                lvKvizovi.setVisibility(View.VISIBLE);
            }
            else {
                kvizovi = dohvaceniKvizovi;
                kvizovi.add(new Kviz(getString(R.string.dodajNoviKviz), new ArrayList<Pitanje>(), new Kategorija("Svi", "0"), ""));

                lf = new ListaFrag();
                df = new DetailFrag();

                Bundle argKategorije = new Bundle();
                argKategorije.putParcelableArrayList(EXTRA_KATEGORIJA_TO_LISTA_FRAG, kategorije);
                lf.setArguments(argKategorije);

                Bundle argDetail = new Bundle();
                argDetail.putParcelableArrayList(EXTRA_KVIZOVI_TO_DETAIL_FRAG, kvizovi);
                df.setArguments(argDetail);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.listPlace, lf);
                ft.replace(R.id.detailPlace, df);
                ft.commit();
            }
        }
        else {
            kvizovi = dohvaceniKvizovi;
            kvizovi.add(new Kviz(getString(R.string.dodajNoviKviz), new ArrayList<Pitanje>(), new Kategorija("Svi", "0"), ""));

            FrameLayout lp = findViewById(R.id.listPlace);
            if (lp == null) {
                kvizoviAdapter = new ListaKvizovaAdapter(this, kvizovi, getResources());
                lvKvizovi.setAdapter(kvizoviAdapter);
                ProgressBar pb = findViewById(R.id.loadingPanel);
                pb.setVisibility(View.GONE);
                spPostojeceKategorije.setVisibility(View.VISIBLE);
                lvKvizovi.setVisibility(View.VISIBLE);

            } else {
                df = new DetailFrag();
                Bundle argDetail = new Bundle();
                argDetail.putParcelableArrayList(EXTRA_KVIZOVI_TO_DETAIL_FRAG, kvizovi);
                df.setArguments(argDetail);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.detailPlace, df);
                ft.commit();
            }
        }
    }

    @Override
    public void onSviKvizoviDone(ArrayList<Kviz> dohvaceniKvizovi, ArrayList<Kategorija> dohvaceneKategorije) {

        //ako se razlikuju velicine znaci da je u medjuvremenu dodato jos kategorija
        if(dohvaceneKategorije.size()!=kategorije.size()-1) {
            kategorije = dohvaceneKategorije;
            String trenutnaKategorija = kategorije.get(pozicijaSpinner).getNaziv();
            kategorije.add(new Kategorija(getString(R.string.sviKvizovi), Integer.toString(R.drawable.question_mark)));
            for(int i = 0; i < kategorije.size(); i++) {
                if(kategorije.get(i).getNaziv().equals(trenutnaKategorija)) {
                    pozicijaSpinner = i;
                    break;
                }
            }
            FrameLayout lp = findViewById(R.id.listPlace);
            if(lp == null) {
                spinnerAdapter = new SpinnerKategorijaAdapter(this, kategorije, getResources(), false);
                spPostojeceKategorije.setAdapter(spinnerAdapter);
                spPostojeceKategorije.setSelection(pozicijaSpinner);

                ProgressBar pb = findViewById(R.id.loadingPanel);
                pb.setVisibility(View.GONE);
                spPostojeceKategorije.setVisibility(View.VISIBLE);
                lvKvizovi.setVisibility(View.VISIBLE);

            }
            else {
                kvizovi = dohvaceniKvizovi;
                kvizovi.add(new Kviz(getString(R.string.dodajNoviKviz), new ArrayList<Pitanje>(), new Kategorija("Svi", "0"), ""));

                lf = new ListaFrag();
                df = new DetailFrag();

                Bundle argKategorije = new Bundle();
                argKategorije.putParcelableArrayList(EXTRA_KATEGORIJA_TO_LISTA_FRAG, kategorije);
                lf.setArguments(argKategorije);

                Bundle argDetail = new Bundle();
                argDetail.putParcelableArrayList(EXTRA_KVIZOVI_TO_DETAIL_FRAG, kvizovi);
                df.setArguments(argDetail);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.listPlace, lf);
                ft.replace(R.id.detailPlace, df);
                ft.commit();
            }
        }
        else {
            kvizovi = dohvaceniKvizovi;
            kvizovi.add(new Kviz(getString(R.string.dodajNoviKviz), new ArrayList<Pitanje>(), new Kategorija("Svi", "0"), ""));

            FrameLayout lp = findViewById(R.id.listPlace);
            if (lp == null) {
                kvizoviAdapter = new ListaKvizovaAdapter(this, kvizovi, getResources());
                lvKvizovi.setAdapter(kvizoviAdapter);
                ProgressBar pb = findViewById(R.id.loadingPanel);
                pb.setVisibility(View.GONE);
                spPostojeceKategorije.setVisibility(View.VISIBLE);
                lvKvizovi.setVisibility(View.VISIBLE);

            } else {
                df = new DetailFrag();
                Bundle argDetail = new Bundle();
                argDetail.putParcelableArrayList(EXTRA_KVIZOVI_TO_DETAIL_FRAG, kvizovi);
                df.setArguments(argDetail);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.detailPlace, df);
                ft.commit();
            }
        }
    }


    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case DohvatiKvizoveIntentServis.STATUS_RUNNING :
                break;
            case DohvatiKvizoveIntentServis.STATUS_FINISHED :
                kvizovi = resultData.getParcelableArrayList("kvizovi");
                kategorije = resultData.getParcelableArrayList("kategorije");

                kategorije.add(new Kategorija(getString(R.string.sviKvizovi), Integer.toString(R.drawable.question_mark)));
                kvizovi.add(new Kviz(getString(R.string.dodajNoviKviz), new ArrayList<Pitanje>(), new Kategorija("Svi", "0"), ""));

                FrameLayout lp = findViewById(R.id.listPlace);

                if(lp != null) {
                    lf = new ListaFrag();
                    df = new DetailFrag();

                    Bundle argKategorije = new Bundle();
                    argKategorije.putParcelableArrayList(EXTRA_KATEGORIJA_TO_LISTA_FRAG, kategorije);
                    lf.setArguments(argKategorije);

                    Bundle argDetail = new Bundle();
                    argDetail.putParcelableArrayList(EXTRA_KVIZOVI_TO_DETAIL_FRAG, kvizovi);
                    df.setArguments(argDetail);

                    FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.listPlace, lf);
                    ft.replace(R.id.detailPlace, df);

                    findViewById(R.id.loadingPanelHorizontal).setVisibility(View.GONE);

                    ft.commit();

                    InputStream is = getResources().openRawResource(R.raw.secret);
                    new DohvatiSveKvizove(is, KvizoviAkt.this).execute();
                }
                else {
                    kvizoviAdapter = new ListaKvizovaAdapter(KvizoviAkt.this, kvizovi, getResources());
                    lvKvizovi.setAdapter(kvizoviAdapter);
                    spinnerAdapter = new SpinnerKategorijaAdapter(this, kategorije, getResources(), false);
                    spPostojeceKategorije.setAdapter(spinnerAdapter);
                    spPostojeceKategorije.setSelection(kategorije.size() - 1);

                    spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            pozicijaSpinner = position;
                            if(!kategorije.get(position).getNaziv().equals("Svi")) {
                                InputStream is = getResources().openRawResource(R.raw.secret);
                                new DohvatiKvizoveIzKategorije(is, KvizoviAkt.this).execute(kategorije.get(position).getNaziv());
                            }
                            else {
                                InputStream is = getResources().openRawResource(R.raw.secret);
                                new DohvatiSveKvizove(is, KvizoviAkt.this).execute();
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                        }
                    });

                    lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            TextView tv = view.findViewById(R.id.tvNazivKviza);
                            String naziv = tv.getText().toString();
                            pokreniIgrajKvizAkt(naziv);
                        }
                    });

                    lvKvizovi.setLongClickable(true);
                    lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                        @Override
                        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                            pokreniDodajKvizAkt(kvizovi.get(position).getFirestoreID());
                            return true;
                        }
                    });

                }

                break;
            case DohvatiKvizoveIntentServis.STATUS_ERROR :
                break;
        }
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        FrameLayout lp = findViewById(R.id.listPlace);
        if(lp != null) {
            lf = new ListaFrag();
            df = new DetailFrag();

            Bundle argKategorije = new Bundle();
            argKategorije.putParcelableArrayList(EXTRA_KATEGORIJA_TO_LISTA_FRAG, kategorije);
            lf.setArguments(argKategorije);

            Bundle argDetail = new Bundle();
            argDetail.putParcelableArrayList(EXTRA_KVIZOVI_TO_DETAIL_FRAG, kvizovi);
            argDetail.putString(EXTRA_FILTER_TO_DETAIL_FRAG, getString(R.string.sviKvizovi));
            df.setArguments(argDetail);

            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.listPlace, lf);
            ft.replace(R.id.detailPlace, df);
            ft.commit();
        }
    }
}
