package ba.unsa.etf.rma.servisi;

import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;

public class DohvatiKategorije extends AsyncTask<Void, Integer, Void> {

    private InputStream is;
    private ArrayList<Kategorija> kategorije;
    private OnKategorijeSearchDone pozivatelj;

    public DohvatiKategorije(InputStream inStream, OnKategorijeSearchDone p) {
        is = inStream;
        pozivatelj = p;
    }

    @Override
    protected Void doInBackground(Void...voids) {

        kategorije = new ArrayList<>();

        GoogleCredential credentials;
        String TOKEN = null;
        try {
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        String projektID = "rma19-568b8";

        try {
            String urlKategorije = "https://firestore.googleapis.com/v1/projects/" + projektID +
                    "/databases/(default)/documents/Kategorije?pageSize=500&access_token=" + TOKEN;
            URL url = new URL(urlKategorije);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            InputStream  in = new BufferedInputStream(urlConnection.getInputStream());
            String dobavljeneKategorije = convertStreamToString(in);

            JSONObject joKategorije = new JSONObject(dobavljeneKategorije);
            JSONArray kategorijaDocuments = joKategorije.optJSONArray("documents");

            if(kategorijaDocuments != null) {
                for (int l = 0; l < kategorijaDocuments.length(); l++) {
                    JSONObject katDocument = kategorijaDocuments.getJSONObject(l);
                    JSONObject katFields = katDocument.getJSONObject("fields");

                    JSONObject katNaziv = katFields.getJSONObject("naziv");
                    String nazivKategorije = katNaziv.getString("stringValue");

                    JSONObject katIkonica = katFields.getJSONObject("idIkonice");
                    int ikonicaID = katIkonica.getInt("integerValue");

                    kategorije.add(new Kategorija(nazivKategorije, Integer.toString(ikonicaID)));
                }
            }
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pozivatelj.onSearchDone(kategorije);
    }

    private String convertStreamToString(InputStream iStream) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(iStream));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                iStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public interface  OnKategorijeSearchDone {
        void onSearchDone(ArrayList<Kategorija> dohvaceneKategorije);
    }

}
