package ba.unsa.etf.rma.fragmenti;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.GridKvizovaAdapter;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;


public class DetailFrag extends Fragment {

    private ArrayList<Kviz> kvizovi;
    private String odabranaKategorija;
    private GridView gridKvizovi;
    private GridKvizovaAdapter adapter;
    private Listener listener;

    public DetailFrag() {
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.listener = (DetailFrag.Listener)context;
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

       View view = inflater.inflate(R.layout.fragment_detail, container, false);
       gridKvizovi = view.findViewById(R.id.gridKvizovi);

       kvizovi = new ArrayList<>();
       adapter = new GridKvizovaAdapter(requireActivity(), kvizovi, getResources());
       gridKvizovi.setAdapter(adapter);

       if (getArguments() != null) {
           ArrayList<Kviz> temp = getArguments().getParcelableArrayList(KvizoviAkt.EXTRA_KVIZOVI_TO_DETAIL_FRAG);
           kvizovi.addAll(temp);
           adapter.notifyDataSetChanged();
       }


       gridKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               TextView tv = view.findViewById(R.id.tvNazivKviza);
               String naziv = tv.getText().toString();
               listener.gridItemClicked(naziv);
           }
       });

       gridKvizovi.setLongClickable(true);
       gridKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
           @Override
           public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
               listener.gridItemLongClicked(kvizovi.get(position).getFirestoreID());
               return true;
           }
       });

       return view;
    }

    public interface Listener {
        void gridItemClicked(String naziv);
        void gridItemLongClicked(String naziv);
    }
}
