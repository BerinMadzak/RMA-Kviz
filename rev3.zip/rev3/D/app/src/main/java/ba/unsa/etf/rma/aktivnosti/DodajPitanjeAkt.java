package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.io.InputStream;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.ListaOdgovoraAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.servisi.DohvatiKvizSaPitanjima;
import ba.unsa.etf.rma.servisi.IndexPitanjaResultReceiver;
import ba.unsa.etf.rma.servisi.PitanjeCreate;

public class DodajPitanjeAkt extends AppCompatActivity implements IndexPitanjaResultReceiver.Receiver,
                                                                  DohvatiKvizSaPitanjima.OnMogucaSearchDone {

    private EditText etNaziv;
    private EditText etOdgovor;
    private ListView lvOdgovori;
    private Button btnDodajOdgovor;
    private Button btnDodajTacan;
    private Button btnDodajPitanje;
    private ArrayList<String> odgovori;
    private String tacanOdgovor;
    private ListaOdgovoraAdapter adapter;
    private Boolean ispravanNaziv;
    private Boolean ispravniOdgovori;
    private Boolean imaTacan;
    private String idKreiranog;
    private int indexTacnog;
    private Intent iData;
    private ArrayList<Pitanje> dodanaPitanja;

    public static final String EXTRA_PITANJE_DPIT_TO_DKVIZ = "novoPit_za_dka";

    private static  final String SIS_ODGOVORI = "odgovori";
    private static  final String SIS_TACAN_ODGOVOR = "tacan_odgovor";
    private static  final String SIS_ET_NAZIV = "etNaziv";
    private static  final String SIS_ET_ODGOVOR = "etOdgovor";
    private static  final String SIS_IMA_TACAN = "imaTacan";
    private static  final String SIS_ISPRAVAN_NAZIV ="okNaziv";
    private static  final String SIS_ISPRAVNI_ODGOVORI = "okOdgovori";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje);

        etNaziv = findViewById(R.id.etNaziv);
        etOdgovor = findViewById(R.id.etOdgovor);
        lvOdgovori = findViewById(R.id.lvOdgovori);
        btnDodajOdgovor = findViewById(R.id.btnDodajOdgovor);
        btnDodajPitanje = findViewById(R.id.btnDodajPitanje);
        btnDodajTacan = findViewById(R.id.btnDodajTacan);

        if(savedInstanceState != null) {
           ucitajSavedIntanceStatePodatke(savedInstanceState);
        }
        else {
            odgovori = new ArrayList<>();
            ispravanNaziv = true;
            imaTacan = true;
            ispravniOdgovori = true;
        }

        adapter = new ListaOdgovoraAdapter(this , odgovori, getResources(), tacanOdgovor);
        lvOdgovori.setAdapter(adapter);

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp = etOdgovor.getText().toString().trim();
                if(!temp.equals("") && !odgovori.contains(temp)) {
                    odgovori.add(temp);
                    adapter.notifyDataSetChanged();
                    etOdgovor.setText("");
                }
            }
        });

        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp = etOdgovor.getText().toString().trim();
                if(!temp.equals("") && !odgovori.contains(temp)) {
                    tacanOdgovor = temp;
                    odgovori.add(temp);
                    indexTacnog = odgovori.size() - 1;
                    adapter = new ListaOdgovoraAdapter(DodajPitanjeAkt.this , odgovori, getResources(), tacanOdgovor);
                    lvOdgovori.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    etOdgovor.setText("");
                    btnDodajTacan.setEnabled(false);
                }
            }
        });

        btnDodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputStream is = getResources().openRawResource(R.raw.secret);
                new DohvatiKvizSaPitanjima(new ArrayList<String>(), new ArrayList<String>(), is, DodajPitanjeAkt.this).execute("");

            }
        });

        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(odgovori != null && odgovori.size()!=0) {
                    if (odgovori.get(position).equals(tacanOdgovor)) {
                        tacanOdgovor = "";
                        btnDodajTacan.setEnabled(true);
                    }
                    odgovori.remove(position);
                    adapter = new ListaOdgovoraAdapter(DodajPitanjeAkt.this, odgovori, getResources(), tacanOdgovor);
                    lvOdgovori.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putStringArrayList(SIS_ODGOVORI, odgovori);
        savedInstanceState.putString(SIS_TACAN_ODGOVOR, tacanOdgovor);
        savedInstanceState.putString(SIS_ET_NAZIV, etNaziv.getText().toString());
        savedInstanceState.putString(SIS_ET_ODGOVOR, etOdgovor.getText().toString());
        savedInstanceState.putBoolean(SIS_IMA_TACAN, imaTacan);
        savedInstanceState.putBoolean(SIS_ISPRAVAN_NAZIV, ispravanNaziv);
        savedInstanceState.putBoolean(SIS_ISPRAVNI_ODGOVORI, ispravniOdgovori);
    }

    private void provjeraValidnostiUnosa() {
        String temp = etNaziv.getText().toString().trim();
        ispravanNaziv = true;
        ispravniOdgovori = true;
        imaTacan = true;

        if(temp.equals(""))
            ispravanNaziv = false;
        else {
            Pitanje tempPit = new Pitanje(temp, "", new ArrayList<String>(), "");
            for(int i=0; i<dodanaPitanja.size(); i++)
                if(dodanaPitanja.contains(tempPit)) {
                    ispravanNaziv = false;
                    break;
                }
        }

        if(!ispravanNaziv) {
            etNaziv.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        }
        else{
            etNaziv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        }

        //Prihvataju se pitanja sa bar 2 odgovora od kojih 1 mora biti tacno
        if(odgovori.size() == 0) {
            etOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
            btnDodajTacan.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
            btnDodajOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
            imaTacan = false;
            ispravniOdgovori = false;
        }
        else {
            if (tacanOdgovor == null || tacanOdgovor.equals("")) {
                imaTacan = false;
            }
            else {
                etOdgovor.setBackgroundColor(getResources().getColor(android.R.color.transparent));
                btnDodajTacan.setBackgroundResource(android.R.drawable.btn_default);
            }

            if (odgovori.size() < 2 && imaTacan) {
                etOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
                btnDodajOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
                ispravniOdgovori = false;
            }
            else {
                etOdgovor.setBackgroundColor(getResources().getColor(android.R.color.transparent));
                btnDodajOdgovor.setBackgroundResource(android.R.drawable.btn_default);
                ispravniOdgovori = true;
            }

            if(!imaTacan) {
                etOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
                btnDodajTacan.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
            }
        }
    }

    private void ucitajSavedIntanceStatePodatke(Bundle savedInstanceState) {
        odgovori = savedInstanceState.getStringArrayList(SIS_ODGOVORI);
        tacanOdgovor = savedInstanceState.getString(SIS_TACAN_ODGOVOR);
        etNaziv.setText(savedInstanceState.getString(SIS_ET_NAZIV));
        etOdgovor.setText(savedInstanceState.getString(SIS_ET_ODGOVOR));
        imaTacan = savedInstanceState.getBoolean(SIS_IMA_TACAN);
        ispravanNaziv = savedInstanceState.getBoolean(SIS_ISPRAVAN_NAZIV);
        ispravniOdgovori = savedInstanceState.getBoolean(SIS_ISPRAVNI_ODGOVORI);
        if (!imaTacan) {
            etOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
            btnDodajTacan.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        }
        if (!ispravniOdgovori) {
            etOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
            btnDodajOdgovor.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        }
        if(!ispravanNaziv) {
            etNaziv.setBackgroundColor(getResources().getColor(R.color.podaci_greska));
        }
    }

    @Override
    public void onReceiveIndexResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case PitanjeCreate.STATUS_RUNNING :
                break;
            case PitanjeCreate.STATUS_FINISHED :
                idKreiranog = resultData.getString("id");
                iData.putExtra("id", idKreiranog);
                finish();
                break;
            case PitanjeCreate.STATUS_ERROR :
                break;
        }
    }

    @Override
    public void onKvizSaPitanjimaDone(ArrayList<Pitanje> dohvacenaDodana, ArrayList<Pitanje> dohvacenaMoguca, ArrayList<String> dodana, ArrayList<String> moguca, Kviz odabraniKviz) {
        dodanaPitanja = dohvacenaDodana;
        dodanaPitanja.addAll(dohvacenaMoguca);
        provjeraValidnostiUnosa();
        if(ispravanNaziv && ispravniOdgovori && imaTacan) {
            String temp = etNaziv.getText().toString().trim();
            iData = new Intent();
            iData.putExtra(EXTRA_PITANJE_DPIT_TO_DKVIZ, new Pitanje(temp, temp, odgovori, tacanOdgovor));
            setResult(AppCompatActivity.RESULT_OK, iData);

            // pokretanje servisa za kreiranje novog pitanja
            Intent servisIntent = new Intent(Intent.ACTION_SYNC, null, DodajPitanjeAkt.this, PitanjeCreate.class);
            servisIntent.putExtra("naziv", temp);
            servisIntent.putStringArrayListExtra("odgovori", odgovori);
            servisIntent.putExtra("tacan", indexTacnog);

            IndexPitanjaResultReceiver indexReceiver = new IndexPitanjaResultReceiver(new Handler());
            indexReceiver.setReceiver(DodajPitanjeAkt.this);
            servisIntent.putExtra("receiver", indexReceiver);

            startService(servisIntent);
        }
        else if(!ispravanNaziv) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DodajPitanjeAkt.this);
            alertDialogBuilder.setTitle("Greska pri kreiranju pitanja");
            alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.alert_icon_red));
            alertDialogBuilder.setNeutralButton(R.string.alertButton, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alertDialogBuilder.setMessage("Uneseno pitanje vec postoji!");
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }
}
