package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class SpinnerKategorijaAdapter extends BaseAdapter {


    private static LayoutInflater inflater = null;
    private ArrayList<Kategorija> data;
    public Resources res;
    private boolean dodajKategoriju;

    public SpinnerKategorijaAdapter(Activity a, ArrayList<Kategorija> items, Resources resLocal, boolean dodajKat) {
        data = items;
        res = resLocal;
        dodajKategoriju = dodajKat;
        inflater = (LayoutInflater)a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        if(data.size() <= 0)
            return 1;
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder {
        TextView tvNazivKategorije;
        TextView tvDodajKategoriju;
        ImageView iwDodajKategoriju;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;

        if(convertView == null) {
            vi = inflater.inflate(R.layout.item_kategorija, parent, false);

            holder = new ViewHolder();
            holder.tvNazivKategorije = vi.findViewById(R.id.tvNazivKategorije);
            holder.tvDodajKategoriju = vi.findViewById(R.id.tvDodajKategoriju);
            holder.iwDodajKategoriju = vi.findViewById(R.id.iwDodajKategoriju);

            vi.setTag(holder);
        }
        else {
            holder = (ViewHolder)vi.getTag();
        }

        if(data.size() <= 0) {
            holder.tvNazivKategorije.setText("");
        }
        else {
            Kategorija temp = data.get(position);

            if(dodajKategoriju) {
                if (temp.getId().equals("dodaj_novi")) {
                    holder.tvNazivKategorije.setVisibility(View.GONE);
                    holder.tvDodajKategoriju.setVisibility(View.VISIBLE);
                    holder.iwDodajKategoriju.setVisibility(View.VISIBLE);
                } else {
                    holder.tvNazivKategorije.setVisibility(View.VISIBLE);
                    holder.tvNazivKategorije.setText(temp.getNaziv());
                    holder.tvDodajKategoriju.setVisibility(View.GONE);
                    holder.iwDodajKategoriju.setVisibility(View.GONE);
                }
            }
            else {
                holder.tvNazivKategorije.setVisibility(View.VISIBLE);
                holder.tvNazivKategorije.setText(temp.getNaziv());
                holder.tvDodajKategoriju.setVisibility(View.GONE);
                holder.iwDodajKategoriju.setVisibility(View.GONE);
                holder.tvNazivKategorije.setTextSize(TypedValue.COMPLEX_UNIT_SP,18);
            }
        }
        return vi;
    }
}
