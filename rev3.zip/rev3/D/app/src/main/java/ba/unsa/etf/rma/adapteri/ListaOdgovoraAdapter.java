package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class ListaOdgovoraAdapter extends BaseAdapter {

    private static LayoutInflater inflater = null;
    private ArrayList<String> data;
    public Resources res;
    private String tacanOdgovor;

    public ListaOdgovoraAdapter(Activity a, ArrayList<String> items, Resources resLocal, String tacanOdg) {
        data = items;
        res = resLocal;
        tacanOdgovor = tacanOdg;
        inflater = (LayoutInflater)a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        if(data.size() <= 0)
            return 1;
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder {
        TextView tvOdgovor;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;

        if(convertView == null) {
            vi = inflater.inflate(R.layout.item_odgovor, parent, false);

            holder = new ViewHolder();
            holder.tvOdgovor = vi.findViewById(R.id.tvOdgovor);

            vi.setTag(holder);
        }
        else {
            holder = (ViewHolder)vi.getTag();
        }

        if(data.size() <= 0) {
            holder.tvOdgovor.setText("");
        }
        else {
            String temp = data.get(position);

            holder.tvOdgovor.setText(temp);
            if (temp.equals(tacanOdgovor)) {
                vi.setBackgroundColor(res.getColor(R.color.tacan_odgovor));
            }
            else {
                vi.setBackgroundColor(res.getColor(android.R.color.transparent));
            }
        }
        return vi;
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }

    public boolean areAllItemsEnabled () {
        return false;
    }
}
