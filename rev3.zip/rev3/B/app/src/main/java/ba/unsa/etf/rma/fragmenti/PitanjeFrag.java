package ba.unsa.etf.rma.fragmenti;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class PitanjeFrag extends Fragment {

    private TextView tekstPitanja;
    private ListView odgovoriPitanja;
    private List<String> lista = new ArrayList<>();
    private ArrayAdapter adapter;

    Kviz k = new Kviz();
    Pitanje p;
    int preostali, tacni, odgovorena = 0;

    private List<Integer> prikazanaPitanja = new ArrayList<>();

    public PitanjeFrag () {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.pitanje_frag, container, false);
        tekstPitanja = (TextView) v.findViewById(R.id.tekstPitanja);
        odgovoriPitanja = (ListView) v.findViewById(R.id.odgovoriPitanja);
        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, lista);

        if(getArguments() != null && getArguments().containsKey("kviz")) {
            k = getArguments().getParcelable("kviz");
        }
        int index = 0;
        if(k.getPitanja().size() == 0) {
            tekstPitanja.setText("Kviz je zavrsen!");
            //sta ovde treba da se desi
        }
        else {
            index = randomIndex(k.getPitanja().size());
            prikazanaPitanja.add(index);
            p = k.getPitanja().get(index);
            lista.addAll(p.getOdgovori());
            odgovoriPitanja.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            tekstPitanja.setText(p.getNaziv());


            final Handler handler = new Handler();

            odgovoriPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(final AdapterView<?> parent, View view, int position, long id) {
                    InformacijeFrag informacijeFrag = (InformacijeFrag) getFragmentManager().findFragmentById(R.id.informacijePlace);
                    preostali = informacijeFrag.preostali;
                    tacni = informacijeFrag.tacni;
                    int indexTacnog = 0;
                    for (int i = 0; i < p.getOdgovori().size(); i++)
                        if (p.getOdgovori().get(i).equals(p.getTacan())) {
                            indexTacnog = i;
                            break;
                        }

                    if (lista.get(position).equals(p.getTacan())) {
                        view.setBackgroundColor(getResources().getColor(R.color.zelena));
                        tacni++;
                    } else if (!lista.get(position).equals(p.getTacan())) {
                        view.setBackgroundColor(getResources().getColor(R.color.crvena));
                        odgovoriPitanja.getChildAt(indexTacnog).setBackgroundColor(getResources().getColor(R.color.zelena));
                    }
                    preostali = k.getPitanja().size() - (++odgovorena);
                    informacijeFrag.change(tacni, odgovorena);

                    if (odgovorena != k.getPitanja().size()) {
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                parent.setBackgroundColor(0);
                                int index1 = randomIndex(k.getPitanja().size());
                                //da se ne bi biralo jedno pitanje vise puta
                                while (prikazanaPitanja.contains(index1)) {
                                    index1 = randomIndex(k.getPitanja().size());
                                    if (!prikazanaPitanja.contains(index1)) break;
                                }
                                prikazanaPitanja.add(index1);
                                p = k.getPitanja().get(index1);
                                lista.clear();
                                lista.addAll(p.getOdgovori());
                                adapter.notifyDataSetChanged();
                                tekstPitanja.setText(p.getNaziv());
                                for (int i = 0; i < odgovoriPitanja.getChildCount(); i++)
                                    odgovoriPitanja.getChildAt(i).setBackgroundColor(0);
                            }
                        }, 2000);
                    } else if (odgovorena == k.getPitanja().size()) {
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                tekstPitanja.setText("Kviz je zavrsen!");
                                lista.clear();
                                adapter.notifyDataSetChanged();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        final String[] ime = new String[1];
                                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                        View view1 = getLayoutInflater().inflate(R.layout.dialog_template, null);
                                        final EditText imeET = (EditText) view1.findViewById(R.id.editText);
                                        Button okButton = (Button) view1.findViewById(R.id.button);
                                        builder.setView(view1);
                                        final AlertDialog dialog = builder.create();
                                        okButton.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                ime[0] = imeET.getText().toString();
                                                RangLista fragment = new RangLista();
                                                Bundle arguments = new Bundle();
                                                arguments.putString("ime" , ime[0]);
                                                fragment.setArguments(arguments);
                                                getFragmentManager().beginTransaction().replace(R.id.pitanjePlace, fragment).commit();
                                                dialog.cancel();
                                            }
                                        });
                                        dialog.show();
                                    }
                                }, 2000);
                            }
                        }, 2000);
                    }
                }
            });
        }
        return v;
    }

    public int randomIndex (int vel) {
        Random rand = new Random();
        return rand.nextInt(vel);
    }
}
