package ba.unsa.etf.rma.fragmenti;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;


public class InformacijeFrag extends Fragment {

    private TextView infNazivKviza, infBrojTacnihPitanja, infBrojPreostalihPitanja, infProcenatTacni;
    private Button btnKraj;

    public static int preostali, tacni;
    public double procenat;
    public String nazivKviza;
    public InformacijeFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.informacije_frag, container, false);
        infNazivKviza = (TextView) v.findViewById(R.id.infNazivKviza);
        infBrojTacnihPitanja = (TextView) v.findViewById(R.id.infBrojTacnihPitanja);
        infBrojPreostalihPitanja = (TextView) v.findViewById(R.id.infBrojPreostalihPitanja);
        infProcenatTacni = (TextView) v.findViewById(R.id.infProcenatTacni);
        btnKraj = (Button) v.findViewById(R.id.btnKraj);

        Kviz k = new Kviz();

        if(getArguments() != null && getArguments().containsKey("kviz")) {
            k = getArguments().getParcelable("kviz");
        }

        preostali = k.getPitanja().size();
        tacni = 0;

        infNazivKviza.setText(k.getNaziv());
        nazivKviza = k.getNaziv();
        if(preostali == 0)
            infBrojPreostalihPitanja.setText("0");
        else
            infBrojPreostalihPitanja.setText(String.valueOf(k.getPitanja().size() - 1));
        infBrojTacnihPitanja.setText("0");

        if(preostali > 0) {
            infProcenatTacni.setText(Double.toString(((double) tacni) / (tacni + preostali)));
            procenat = ((double) tacni) / (tacni + preostali);
        } else {
            infProcenatTacni.setText("0%");
            procenat = 0;
        }

        btnKraj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        return v;
    }

    public void change(int brojTacnih, int brojOdgovorenih) {
        tacni = brojTacnih;
        if(brojOdgovorenih == preostali)
            infBrojPreostalihPitanja.setText("0");
        else
            infBrojPreostalihPitanja.setText(String.valueOf(preostali - brojOdgovorenih - 1));
        infBrojTacnihPitanja.setText(String.valueOf(brojTacnih));
        infProcenatTacni.setText(String.valueOf(((double)brojTacnih) / (brojOdgovorenih) * 100) + "%");
        procenat = ((double)brojTacnih) / (brojOdgovorenih) * 100;
    }


}
