package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;

public class AdapterZaOdgovore extends ArrayAdapter<Pair<String, Boolean>> {

    private Context context;
    private List<Pair<String, Boolean>> list = new ArrayList<>();

    public AdapterZaOdgovore(@NonNull Context context, int resource, @NonNull List<Pair<String, Boolean>> objects) {
        super(context, resource, objects);
        this.context = context;
        list = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @Nullable ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.list_item_kviz, parent, false);
        }

        String s = list.get(position).first;

        ImageView image = (ImageView)listItem.findViewById(R.id.idKategorije);
        image.setImageResource(0);

        TextView naziv = (TextView) listItem.findViewById(R.id.nazivKviza);
        naziv.setText(s);
        if(list.get(position).second) {
            naziv.setBackgroundColor(Color.GREEN);
        } else {
            naziv.setBackgroundColor(0);
        }
        return listItem;
    }
}
