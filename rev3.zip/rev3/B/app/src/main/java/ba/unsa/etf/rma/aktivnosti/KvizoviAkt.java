package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListFrag;
import ba.unsa.etf.rma.klase.AdapterZaKvizove;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static com.google.common.collect.Lists.newArrayList;

//TODO kad se edituje ostane nepromijenjeno ime sve dok se ponovo ne selektuje
// kategorija; kad se doda u svi;


public class KvizoviAkt extends AppCompatActivity implements ListFrag.OnItemClick {

    public static Map<Pitanje, String> pitanjaDatabase = new HashMap<>(); //pitanje sa atributima datim u bazi (String - naziv, ArrayList<String> - idevi pitanja, String - id kategorije)
    public static Map<Object, String> pitanjaApp = new HashMap<>(); //pitanje ciji su atributi iz prethodnih spirala
    public static Map<Kviz, String> kvizoviDatabase = new HashMap<>(); //vazi isto sto i za pitanje
    public static Map<Pitanje, String> mogucaPitanjaDatabase = new HashMap<>();
    public static ArrayList<Kviz> kvizoviApp = new ArrayList<>();
    public static Map<Kategorija, String> kategorijeDatabase = new HashMap<>();
    public static Map<Object, String> kategorijeApp = new HashMap<>();
    //public static Map<Pitanje, String> mogucaPitanjaApp = new HashMap<>();
    private Map<Kviz, String> selektovaniKvizovi = new HashMap<>();


    public class DobavljanjePoKategoriji extends AsyncTask<String, Void, Void> {
        private String idKatIzSpinera;
        private AsyncResponse delegate = null;

        public DobavljanjePoKategoriji(String id, AsyncResponse delegate) {
            idKatIzSpinera = id;
            this.delegate = delegate;
        }

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;
            String query = String.format("{\"structuredQuery\": {\"where\": {\"fieldFilter\": {\"field\" : {\"fieldPath\": \"idKategorije\"}, \"op\":\"EQUAL\"," +
                    "\"value\": {\"stringValue\": \"%s\"}}}, \"select\": {\"fields\": [{\"fieldPath\": \"idKategorije\"}, {\"fieldPath\": \"naziv\"}, " +
                    "{\"fieldPath\": \"pitanja\"}]}, \"from\": [{\"collectionId\": \"Kvizovi\"}], \"limit\": 1000}}", idKatIzSpinera);
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents:runQuery?access_token=";
                try {
                    URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                    conn.setDoOutput(true);
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Accept", "application/json");
                    try (OutputStream os = conn.getOutputStream()) {
                        byte[] input = query.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }

                    int code = conn.getResponseCode();
                    InputStream odgovor = conn.getInputStream();
                    String odg;
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while ((responseLine = br.readLine()) != null) {
                            response.append(responseLine.trim());
                        }
                        Log.d("ODGOVOR", response.toString());
                        odg = response.toString();
                    }

                    odg = "{\"documents\": " + odg + "}";


                    JSONObject jsonObject = new JSONObject(odg);
                    JSONArray documents = jsonObject.getJSONArray("documents");
                    for(int i = 0; i < documents.length(); i++) {
                        JSONObject document1 = documents.getJSONObject(i);
                        if (document1.has("document")) {
                            JSONObject document = document1.getJSONObject("document");
                            ArrayList<String> idPitanja = new ArrayList<>();
                            String[] name = document.getString("name").split("/");
                            String id = name[name.length - 1];
                            JSONObject fields = document.getJSONObject("fields");
                            String idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
                            String naziv = fields.getJSONObject("naziv").getString("stringValue");
                            JSONObject jsonPitanjaObj = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
                            if(jsonPitanjaObj.has("values")) {
                                JSONArray jsonPitanja = jsonPitanjaObj.getJSONArray("values");
                                for (int j = 0; j < jsonPitanja.length(); j++) {
                                    idPitanja.add(jsonPitanja.getJSONObject(j).getString("stringValue"));
                                }
                            }
                            selektovaniKvizovi.put(new Kviz(naziv, idKategorije, idPitanja), id);
                        }
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            delegate.processFinish("");
        }
    }

    //dobavljanje Kvizova, Kategorija i Pitanja iz Firebase
    public class DobavljanjeKolekcija extends AsyncTask<String, Void, String> {

        AsyncResponse delegate = null;

        public DobavljanjeKolekcija(AsyncResponse delegate) {
            this.delegate = delegate;
        }

        @Override
        protected String doInBackground(String... params) {
            GoogleCredential credentials;
            String idKviza = null;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Kvizovi?access_token=";
                String odg = pristupBazi(url, TOKEN);

                JSONObject jsonObject = new JSONObject(odg);
                JSONArray documents;
                if(jsonObject.has("documents")) {
                    documents = jsonObject.getJSONArray("documents");
                    for (int i = 0; i < documents.length(); i++) {
                        JSONObject document = documents.getJSONObject(i);
                        String id = null;
                        ArrayList<String> idPitanja = new ArrayList<>();
                        String[] name = document.getString("name").split("/");
                        id = name[name.length - 1];
                        idKviza = id;
                        JSONObject fields = document.getJSONObject("fields");
                        String idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
                        String naziv = fields.getJSONObject("naziv").getString("stringValue");
                        JSONObject jsonPitanjaObj = fields.getJSONObject("pitanja").getJSONObject("arrayValue");
                        if (jsonPitanjaObj.has("values")) {
                            JSONArray jsonPitanja = jsonPitanjaObj.getJSONArray("values");
                            for (int j = 0; j < jsonPitanja.length(); j++) {
                                idPitanja.add(jsonPitanja.getJSONObject(j).getString("stringValue"));
                            }
                        }
                        if (!daLiPostojiKviz(kvizoviDatabase, id))
                            kvizoviDatabase.put(new Kviz(naziv, idKategorije, idPitanja), id);

                    }
                }
                url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Pitanja?access_token=";
                odg = pristupBazi(url, TOKEN);
                jsonObject = new JSONObject(odg);
                if(jsonObject.has("documents")) {
                    documents = jsonObject.getJSONArray("documents");
                    int indexTacnog;
                    for (int i = 0; i < documents.length(); i++) {
                        JSONObject document = documents.getJSONObject(i);
                        ArrayList<String> odgovori = new ArrayList<>();
                        String[] name = document.getString("name").split("/");
                        String id = name[name.length - 1];
                        JSONObject fields = document.getJSONObject("fields");
                        indexTacnog = fields.getJSONObject("indexTacnog").getInt("integerValue");
                        String naziv = fields.getJSONObject("naziv").getString("stringValue");
                        JSONObject jsonOdgovoriObj = fields.getJSONObject("odgovori").getJSONObject("arrayValue");
                        JSONArray jsonOdgovori = jsonOdgovoriObj.getJSONArray("values");
                        for (int j = 0; j < jsonOdgovori.length(); j++) {
                            odgovori.add(jsonOdgovori.getJSONObject(j).getString("stringValue"));
                        }

                        pitanjaDatabase.put(new Pitanje(naziv, indexTacnog, odgovori), id);
                    }
                }

                url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Kategorije?access_token=";
                odg = pristupBazi(url, TOKEN);
                jsonObject = new JSONObject(odg);
                if(jsonObject.has("documents")) {
                    documents = jsonObject.getJSONArray("documents");
                    for (int i = 0; i < documents.length(); i++) {
                        JSONObject document = documents.getJSONObject(i);
                        String[] name = document.getString("name").split("/");
                        String id = name[name.length - 1];
                        JSONObject fields = document.getJSONObject("fields");
                        int idIkonice = fields.getJSONObject("idIkonice").getInt("integerValue");
                        String naziv = fields.getJSONObject("naziv").getString("stringValue");
                        kategorijeDatabase.put(new Kategorija(naziv, Integer.toString(idIkonice)), id);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return idKviza;
        }

        @Override
        protected void onPostExecute(String res) {
            delegate.processFinish(res);
        }
    }

    private Spinner spinner;
    private ListView listView;

    private ArrayList<Kategorija> dodaneKategorije = new ArrayList<>();
    public ArrayList<Kviz> kvizovi = new ArrayList<>();
    AdapterZaKvizove kvizAd;
    ArrayAdapter<Kategorija> spinerAd;

    private Boolean siriL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);

        spinner = (Spinner) findViewById(R.id.spPostojeceKategorije);
        listView = (ListView) findViewById(R.id.lvKvizovi);

        dodaneKategorije.add(new Kategorija("Svi", "54"));
        kvizovi.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));


        new DobavljanjeKolekcija(new AsyncResponse() {
            @Override
            public void processFinish(String output) {
                dodaneKategorije.addAll(0, izdvojiKategorije());
                spinerAd.notifyDataSetChanged();
                spinner.setSelection(dodaneKategorije.size() - 1);
                izdvojiPitanja(pitanjaDatabase);
                kvizovi.addAll(0, izdvojiKvizove(kvizoviDatabase));
                kvizAd.notifyDataSetChanged();
                izdvojiMoguca();
            }
        }).execute(" ");


        if (spinner != null || listView != null) {

            spinerAd = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dodaneKategorije);
            spinerAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinerAd);


            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(final AdapterView<?> parent, View view, final int position, long id) {
                    final ArrayList<Kviz> kvizovi1 = new ArrayList<>(); //selektovani
                    if (position == dodaneKategorije.size() - 1) {
                        izdvojiMoguca();
                        izdvojiPitanja(pitanjaDatabase);
                        kvizovi = izdvojiKvizove(kvizoviDatabase);
                        kvizovi.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                        kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi);
                    } else {
                        new DobavljanjePoKategoriji(kategorijeApp.get(dodaneKategorije.get(position)), new AsyncResponse() {
                            @Override
                            public void processFinish(String output) {
                                izdvojiPitanja(pitanjaDatabase);
                                kvizovi1.addAll(0, izdvojiKvizove(selektovaniKvizovi));
                                kvizovi1.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                                kvizAd.notifyDataSetChanged();
                                selektovaniKvizovi.clear();
                            }
                        }).execute(" ");
                        kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi1);
                    }
                    listView.setAdapter(kvizAd);

                    listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                        @Override
                        public boolean onItemLongClick(AdapterView<?> parent1, View view1, int position1, long id1) {
                            ArrayList<Kviz> kvizovi1 = new ArrayList<>();
                            for (int i = 0; i < kvizovi.size() - 1; i++) {
                                if (dodaneKategorije.get(position).getNaziv().equals(kvizovi.get(i).getKategorija().getNaziv()))
                                    kvizovi1.add(kvizovi.get(i));
                            }

                            kvizovi1.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                            Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            intent.putExtra("kategorije", (Serializable) dodaneKategorije);
                            intent.putExtra("sviKvizovi", (Serializable) kvizovi);
                            if (position == dodaneKategorije.size() - 1) {
                                if (position1 == kvizovi.size() - 1) {
                                    intent.putExtra("dodavanje", true);
                                } else {
                                    intent.putExtra("dodavanje", false);
                                    intent.putExtra("pozicija", position1);
                                    Kviz posalji = kvizovi.get(position1);
                                    intent.putExtra("naziv", posalji.getNaziv());
                                    intent.putExtra("pitanja", (Serializable) posalji.getPitanja());
                                    intent.putExtra("kategorija", (Serializable) posalji.getKategorija());
                                }
                            } else {
                                if (position1 == kvizovi1.size() - 1) {
                                    intent.putExtra("dodavanje", true);
                                } else {
                                    intent.putExtra("dodavanje", false);
                                    intent.putExtra("pozicija", position1);
                                    Kviz posalji = kvizovi1.get(position1);
                                    intent.putExtra("naziv", posalji.getNaziv());
                                    intent.putExtra("pitanja", (Serializable) posalji.getPitanja());
                                    intent.putExtra("kategorija", (Serializable) posalji.getKategorija());
                                }
                            }
                            KvizoviAkt.this.startActivityForResult(intent, 3);
                            return true;
                        }
                    });


                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position2, long id) {
                            if (position == dodaneKategorije.size() - 1) {
                                if (position2 != kvizovi.size() - 1) {
                                    Intent i = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                                    i.putExtra("kviz", (Parcelable) kvizovi.get(position2));
                                    KvizoviAkt.this.startActivity(i);
                                }
                            } else if (position2 != kvizovi1.size() - 1) {
                                Intent i = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                                i.putExtra("kviz", (Parcelable) kvizovi1.get(position2));
                                KvizoviAkt.this.startActivity(i);
                            }
                        }
                    });
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

        } else if (listView == null) {
            siriL = false;

            FragmentManager fragmentManager = getSupportFragmentManager();
            FrameLayout detailPlace = (FrameLayout) findViewById(R.id.detailPlace);
            if (detailPlace != null) {
                siriL = true;
                DetailFrag detailFrag;
                detailFrag = (DetailFrag) fragmentManager.findFragmentById(R.id.detailPlace);
                if (detailFrag == null) {
                    detailFrag = new DetailFrag();
                    fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
                }
            }

            ListFrag listFrag = (ListFrag) fragmentManager.findFragmentByTag("Lista");
            if (listFrag == null) {
                listFrag = new ListFrag();
                Bundle argumenti = new Bundle();
                argumenti.putParcelableArrayList("kategorije", dodaneKategorije);
                listFrag.setArguments(argumenti);
                fragmentManager.beginTransaction().replace(R.id.listPlace, listFrag, "Lista").commit();
            } else {
                fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            }
        }
    }

   @Override
    protected void onActivityResult ( int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 3 && resultCode == DodajKvizAkt.RESULT_OK) {
            boolean dodavanje = data.getBooleanExtra("dodavanje", false);
            dodaneKategorije.addAll(dodaneKategorije.size() - 1, (ArrayList<Kategorija>) data.getSerializableExtra("noveKategorije"));
            spinerAd.notifyDataSetChanged();
            if(dodavanje) {
                for(int i = 0; i < kvizoviApp.size(); i++)
                    if(!kvizovi.contains(kvizoviApp.get(i)))
                        kvizovi.add(0, kvizoviApp.get(i));
                kvizAd = new AdapterZaKvizove(getApplicationContext(), android.R.layout.simple_list_item_1, kvizovi);
                listView.setAdapter(kvizAd);
                spinner.setSelection(0);

            } else {

                spinner.setSelection(dodaneKategorije.size()-1);
                izdvojiPitanja(pitanjaDatabase);
                kvizovi = izdvojiKvizove(kvizoviDatabase);
                kvizovi.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));
                kvizAd = new AdapterZaKvizove(this, android.R.layout.simple_list_item_1, kvizovi);
                listView.setAdapter(kvizAd);
            }

        } else if (requestCode == 3 && resultCode == DodajKvizAkt.RESULT_CANCELED) {
            dodaneKategorije.addAll(dodaneKategorije.size() - 1, (ArrayList<Kategorija>) data.getSerializableExtra("noveKategorije"));
            spinerAd.notifyDataSetChanged();
            spinner.setSelection(dodaneKategorije.size()-1);
        }
    }

    @Override
    public void onItemClicked(int pos) {
        Bundle bundle = new Bundle();
        ArrayList<Kviz> kvizovi1 = new ArrayList<>();
        for(int i = 0; i < kvizovi.size() - 1; i++)
            if(kvizovi.get(i).getKategorija().equals(dodaneKategorije.get(pos)))
                kvizovi1.add(kvizovi.get(i));
        kvizovi1.add(new Kviz("Dodaj kviz", (ArrayList<Pitanje>) null, null));

        bundle.putParcelableArrayList("sviKvizovi", kvizovi);
        bundle.putParcelableArrayList("kvizovi", kvizovi1);
        bundle.putParcelableArrayList("kategorije", dodaneKategorije);
        bundle.putParcelable("kategorija", dodaneKategorije.get(pos));
        DetailFrag detailFrag = new DetailFrag();
        detailFrag.setArguments(bundle);
        if(siriL) {
            getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
        } else {
            getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, detailFrag).addToBackStack(null).commit();
        }
    }

    private static String pristupBazi(String url, String TOKEN) {
        String odg = null;
        try {
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.connect();
            InputStream odgovor = conn.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                odg = response.toString();
                Log.d("ODGOVOR", response.toString());
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return odg;
    }


    private static ArrayList<Kategorija> izdvojiKategorije() {
        ArrayList<Kategorija> res = new ArrayList<>();
        for(Map.Entry<Kategorija, String> i : kategorijeDatabase.entrySet()) {
            Kategorija kategorija = new Kategorija(i.getKey().getNaziv(), i.getKey().getId());
            res.add(kategorija);
            kategorijeApp.put(kategorija, i.getValue());
        }
        return res;
    }


    public static ArrayList<Pitanje> izdvojiPitanja(Map<Pitanje, String> mapa) {
        ArrayList<Pitanje> res = new ArrayList<>();
        for(Map.Entry<Pitanje, String> i : mapa.entrySet()) {
            Pitanje pitanje = new Pitanje(i.getKey().getNaziv(), i.getKey().getNaziv(), i.getKey().getOdgovori(), i.getKey().getOdgovori().get(i.getKey().getIndexTacnog()));
            res.add(pitanje);
            pitanjaApp.put(pitanje, i.getValue());
        }
        return res;
    }

    //naziv, idkategorije, idpitanja
    public static ArrayList<Kviz> izdvojiKvizove(Map<Kviz, String> mapa) {
        ArrayList<Kviz> res = new ArrayList<>();
        for(Map.Entry<Kviz, String> i : mapa.entrySet()) {
            ArrayList<Pitanje> pitanja = new ArrayList<>();
            String naziv = i.getKey().getNaziv();
            Kategorija kategorija = (Kategorija) getKey(kategorijeApp,  String.valueOf(i.getKey().getKategorijaId()));
            for(int j = 0; j < i.getKey().getPitanjaId().size(); j++)
                pitanja.add((Pitanje)getKey(pitanjaApp, i.getKey().getPitanjaId().get(j)));
            Kviz kviz = new Kviz(naziv, pitanja, kategorija);
            kvizoviApp.add(kviz);
            res.add(0, kviz);
        }
        return res;
    }

    private static Object getKey(Map<Object, String> map, String value) {
        Object res = null;
        for(Map.Entry<Object, String> i : map.entrySet()) {
            if(i.getValue().equals(value))
                res = i.getKey();
        }
        return res;
    }

    public static boolean daLiPostojiKategorija (Map<Kategorija, String> map, String s) {
        for(Map.Entry<Kategorija, String> i : map.entrySet())
            if(i.getKey().getNaziv().equals(s))
                return true;
        return false;
    }

    public static boolean daLiPostojiKviz (Map<Kviz, String> map, String s) {
        for(Map.Entry<Kviz, String> i : map.entrySet())
            if(i.getKey().getNaziv().equals(s))
                return true;
        return false;
    }

    public static boolean daLiPostojiPitanje (Map<Pitanje, String> map, String s) {
        for(Map.Entry<Pitanje, String> i : map.entrySet())
            if(i.getKey().getNaziv().equals(s))
                return true;
        return false;
    }

    public static Kviz dajKvizSaNazivom(Map<Kviz, String> map, String naziv) {
        Kviz k = null;
        for(Map.Entry<Kviz, String> i : map.entrySet()) {
            if(i.getKey().getNaziv().equals(naziv))
                k = i.getKey();
        }
        return k;
    }

    public static Kategorija dajKategorijuSaNazivom(Map<Kategorija, String> map, String naziv) {
        Kategorija k = null;
        for(Map.Entry<Kategorija, String> i : map.entrySet()) {
            if(i.getKey().getNaziv().equals(naziv))
                k = i.getKey();
        }
        return k;
    }

    public static Pitanje dajPitanjeSaNazivom(Map<Pitanje, String> map, String naziv) {
        Pitanje k = null;
        for(Map.Entry<Pitanje, String> i : map.entrySet()) {
            if(i.getKey().getNaziv().equals(naziv))
                k = i.getKey();
        }
        return k;
    }

    private static void izdvojiMoguca () {
        for(Map.Entry<Pitanje, String> p : pitanjaDatabase.entrySet()) {
            boolean dodano = false;
            for(Map.Entry<Kviz, String> k : kvizoviDatabase.entrySet()) {
                if(k.getKey().getPitanjaId().contains(p.getValue())) {
                    dodano = true;
                    break;
                }
            }
            if(!dodano) mogucaPitanjaDatabase.put(p.getKey(), p.getValue());
        }
    }
}
