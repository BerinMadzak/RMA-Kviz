package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.AdapterZaDodanaPitanja;
import ba.unsa.etf.rma.klase.AdapterZaPitanja;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.CustomDialog;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizoviApp;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizoviDatabase;
import static com.google.common.collect.Lists.newArrayList;

public class DodajKvizAkt extends AppCompatActivity {

    public class EditovanjeKviza extends AsyncTask<String, Void, Void> {
        private Kviz k;
        private AsyncResponse delegate = null;
        private String idKviza;

        public EditovanjeKviza(Kviz k, String idKviza, AsyncResponse delegate) {
            this.k = k;
            this.delegate = delegate;
            this.idKviza = idKviza;
        }

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Kvizovi/" + idKviza +"?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");


                String dokument = String.format("{ \"fields\": {\"idKategorije\" : {\"stringValue\": \"%s\"}, \"naziv\": {\"stringValue\": \"%s\"}, \"pitanja\": {\"arrayValue\": {\"values\": [", k.getKategorijaId(), k.getNaziv());
                for(int i = 0; i < k.getPitanjaId().size(); i++) {
                    dokument += String.format("{\"stringValue\": \"%s\"}", k.getPitanjaId().get(i));
                    if(i != k.getPitanjaId().size() - 1)
                        dokument += ",";
                }
                dokument += String.format("]}}}}");

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                String odg;
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                    odg = response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            delegate.processFinish(" ");
        }
    }


    public class KreiranjeKviza extends AsyncTask<String, Void, String> {
        private Kviz k;
        private String idKviza;

        AsyncResponse delegat = null;

        public KreiranjeKviza(Kviz k, AsyncResponse delegat)
        {
            this.k = k;
            this.delegat = delegat;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Kvizovi?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");


                String dokument = String.format("{ \"fields\": {\"idKategorije\" : {\"stringValue\": \"%s\"}, \"naziv\": {\"stringValue\": \"%s\"}, \"pitanja\": {\"arrayValue\": {\"values\": [", k.getKategorijaId(), k.getNaziv());
                for(int i = 0; i < k.getPitanjaId().size(); i++) {
                    dokument += String.format("{\"stringValue\": \"%s\"}", k.getPitanjaId().get(i));
                    if(i != k.getPitanjaId().size() - 1)
                        dokument += ",";
                }
                dokument += String.format("]}}}}");

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                String odg;
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                    odg = response.toString();
                }

                JSONObject jsonObject = new JSONObject(odg);
                String[] name = jsonObject.getString("name").split("/");
                idKviza = name[name.length-1];
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return idKviza;
        }

        @Override
        protected void onPostExecute(String s) {
            delegat.processFinish(s);
        }
    }

    private Spinner spinner;
    private ListView listViewDodana, listViewMoguca;
    private EditText editText;
    private Button button;
    private Button importovanjeBtn;

    public ArrayList<Pitanje> mogucaPit = new ArrayList<>();
    public ArrayList<Pitanje> dodanaPit = new ArrayList<>();
    public ArrayList<String> pitanjaSaId = new ArrayList<>();

    AdapterZaDodanaPitanja adapterDodana;
    AdapterZaPitanja adapterMoguca;
    ArrayAdapter<Kategorija> spinerAd;

    Kviz kviz = new Kviz(" ", (ArrayList<Pitanje>) null, null);
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    ArrayList<Kategorija> noveKategorije = new ArrayList<>();
    ArrayList<Kviz> sviKvizovi = new ArrayList<>();
    Kviz k = new Kviz();
    int pozicija = 0;

    private String idKategorije;

    private static final int READ_REQUEST_CODE = 42;

    @Override
    public void onBackPressed() {
        Intent intent = getIntent();
        intent.putExtra("noveKategorije", (Serializable) noveKategorije);
        setResult(DodajKvizAkt.RESULT_CANCELED, intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        mogucaPit = KvizoviAkt.izdvojiPitanja(KvizoviAkt.mogucaPitanjaDatabase);

        final String idEdit = null;

        dodanaPit.add(new Pitanje("Dodaj pitanje", null, null, null));

        spinner = (Spinner) findViewById(R.id.spKategorije);
        listViewDodana = (ListView) findViewById(R.id.lvDodanaPitanja);
        listViewMoguca = (ListView) findViewById(R.id.lvMogucaPitanja);
        editText = (EditText) findViewById(R.id.etNaziv);
        button = (Button) findViewById(R.id.btnDodajKviz);
        importovanjeBtn = (Button) findViewById(R.id.btnImportKviz);

        sviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");
        kategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("kategorije");
        final boolean dodavanje = getIntent().getBooleanExtra("dodavanje", false);
        spinerAd = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategorije);
        spinerAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinerAd);
        if(dodavanje == false) {
            pozicija = getIntent().getIntExtra("pozicija", 0);
            k = new Kviz(getIntent().getStringExtra("naziv"), (ArrayList<Pitanje>) getIntent().getSerializableExtra("pitanja"), (Kategorija) getIntent().getSerializableExtra("kategorija"));
            dodanaPit.addAll(0, k.getPitanja());
            editText.setText(k.getNaziv());
            //postavljanje spiner-itema na kategoriju kviza koji editujemo
            for(int i = 0; i < spinerAd.getCount(); i++) {
                if(k.getKategorija().getNaziv().equals(spinerAd.getItem(i).getNaziv())){
                    spinner.setSelection(i);
                    break;
                }
            }
            importovanjeBtn.setEnabled(false);
        } else {
            importovanjeBtn.setEnabled(true);
        }

        kategorije.add(new Kategorija("Dodaj kategoriju", null));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position == kategorije.size() - 1) {
                    Intent i = new Intent(getApplicationContext(), DodajKategorijuAkt.class);
                    i.putExtra("postojeceKategorije", (Serializable) kategorije);
                    DodajKvizAkt.this.startActivityForResult(i, 2);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        adapterDodana = new AdapterZaDodanaPitanja(this, dodanaPit);
        adapterMoguca = new AdapterZaPitanja(this, mogucaPit);
        listViewDodana.setAdapter(adapterDodana);
        listViewMoguca.setAdapter(adapterMoguca);


        listViewDodana.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if(position == dodanaPit.size() - 1) {
                Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                DodajKvizAkt.this.startActivityForResult(intent, 1);
            }
            if(position != dodanaPit.size() - 1) {
                mogucaPit.add(dodanaPit.get(position));
                KvizoviAkt.mogucaPitanjaDatabase.put(nadjiPitanjeIId(dodanaPit.get(position)).first, nadjiPitanjeIId(dodanaPit.get(position)).second);
                dodanaPit.remove(position);
                adapterMoguca.notifyDataSetChanged();
                adapterDodana.notifyDataSetChanged();
            }
            }
        });
        listViewMoguca.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            dodanaPit.add(dodanaPit.size() - 1, mogucaPit.get(position));
            KvizoviAkt.mogucaPitanjaDatabase.remove(nadjiPitanjeIId(mogucaPit.get(position)).first);
            mogucaPit.remove(position);
            adapterMoguca.notifyDataSetChanged();
            adapterDodana.notifyDataSetChanged();
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             //   if (dodavanje && (editText.getText().toString().isEmpty() || sviKvizovi.contains(new Kviz(editText.getText().toString(), (ArrayList<Pitanje>) null, null)))) {
                if(dodavanje && KvizoviAkt.daLiPostojiKviz(kvizoviDatabase, editText.getText().toString())) {
                    editText.setBackgroundColor(Color.RED);
                } else {
                    editText.setBackgroundColor(0);
                    Intent intent = getIntent();
                    intent.putExtra("noveKategorije", (Serializable) noveKategorije);
                    if (dodavanje) {
                        dodanaPit.remove(dodanaPit.size() - 1);
                      intent.putExtra("nazivKviza", editText.getText().toString());
                        intent.putExtra("pitanja", (Serializable) dodanaPit);
                        intent.putExtra("kategorija", (Serializable) spinner.getSelectedItem());
                       intent.putExtra("dodavanje", true);
                        final Kviz k = new Kviz (editText.getText().toString(), dodanaPit, (Kategorija) spinner.getSelectedItem());

                        pitanjaSaId = new ArrayList<>();
                        for(int i = 0; i < k.getPitanja().size(); i++) {
                            Pitanje pIzBaze = KvizoviAkt.dajPitanjeSaNazivom(KvizoviAkt.pitanjaDatabase, k.getPitanja().get(i).getNaziv());
                            if(pIzBaze != null)
                                pitanjaSaId.add(KvizoviAkt.pitanjaDatabase.get(pIzBaze));
                        }
                        idKategorije = KvizoviAkt.kategorijeDatabase.get(KvizoviAkt.dajKategorijuSaNazivom(KvizoviAkt.kategorijeDatabase, k.getKategorija().getNaziv()));
                        final Kviz k1 = new Kviz(k.getNaziv(), idKategorije, pitanjaSaId);


                        kvizoviApp.add(new Kviz(editText.getText().toString(), dodanaPit, (Kategorija) spinner.getSelectedItem()));
                        new KreiranjeKviza(k1, new AsyncResponse() {
                            @Override
                            public void processFinish(String output) {
                                KvizoviAkt.kvizoviDatabase.put(k1, output);
                             //   KvizoviAkt.kvizoviApp.put(k, output);
                            }
                        }).execute("kviz");
                    } else {
                        dodanaPit.remove(dodanaPit.size() - 1);
                        intent.putExtra("nazivKviza", editText.getText().toString());
                        intent.putExtra("pitanja", (Serializable) dodanaPit);
                        intent.putExtra("kategorija", (Serializable) k.getKategorija());
                        intent.putExtra("dodavanje", false);
                        intent.putExtra("pozicija", pozicija);
                        final Kviz kviz1 = KvizoviAkt.dajKvizSaNazivom(kvizoviDatabase, k.getNaziv());
                        kviz1.setPitanjaId(dajId(dodanaPit));
                        kviz1.setNaziv(editText.getText().toString());
                        new EditovanjeKviza(kviz1, kvizoviDatabase.get(kviz1), new AsyncResponse() {
                            @Override
                            public void processFinish(String output) {
                                for(Map.Entry<Kviz, String> i : kvizoviDatabase.entrySet())
                                    if(i.getKey().getNaziv().equals(k.getNaziv())) {
                                        i.getKey().setNaziv(kviz1.getNaziv());
                                        i.getKey().setPitanjaId(kviz1.getPitanjaId());
                                    }
                            }
                        }).execute(" ");
                    }
                    for(Map.Entry<Kviz, String> i : kvizoviDatabase.entrySet())
                        System.out.println(i.getKey().getNaziv() + " " + i.getKey().getKategorijaId());
                    setResult(DodajKvizAkt.RESULT_OK, intent);
                    finish();
                }
            }
        });

        importovanjeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                startActivityForResult(intent, READ_REQUEST_CODE);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if(requestCode == 1 && resultCode == DodajPitanjeAkt.RESULT_OK) {
            String naziv = data.getStringExtra("nazivPitanja");
            String text = data.getStringExtra("textPitanja");
            ArrayList<String> odg = data.getStringArrayListExtra("spisakOdgovora");
            String tacanOdg = data.getStringExtra("tacanOdgovor");
            Pitanje p = new Pitanje(naziv, text, odg, tacanOdg);
            dodanaPit.add(dodanaPit.size() - 1, p);
            adapterDodana.notifyDataSetChanged();
        } else if(requestCode == 2 && resultCode == DodajKategorijuAkt.RESULT_OK) {
            String imeKategorije = data.getStringExtra("naziv");
            String ikona = data.getStringExtra("ikona");
            Kategorija nova = new Kategorija(imeKategorije, ikona);
            kategorije.add(0, nova);
            noveKategorije.add(nova);
            spinerAd.notifyDataSetChanged();
        } else if(requestCode == READ_REQUEST_CODE && resultCode == DodajKvizAkt.RESULT_OK) {
            Uri uri = null;
            if (data != null) {
                uri = data.getData();
            }
            List<String> list = new ArrayList<>();
            try {
                list = readTextFromUri(uri);
            } catch (IOException e) {
                e.printStackTrace();
            }

            Kviz k = new Kviz();

            //da li kviz sa istim nazivom vec postoji
            String nazivKviza = podijeliRed(list.get(0)).get(0);
            boolean greska = false;
            for (int j = 0; j < sviKvizovi.size(); j++) {
                if (sviKvizovi.get(j).getNaziv().equals(nazivKviza)) {
                    openDialog("Kviz kojeg importujete već postoji!");
                    greska = true;
                }
            }


            String nazivKategorije = podijeliRed(list.get(0)).get(1);
            boolean postojiKat = false;
            for(Kategorija kat : kategorije) {
                if (kat.getNaziv().equals(nazivKategorije)) {
                    k.setKategorija(kat);
                    spinner.setSelection(spinerAd.getPosition(kat));
                    postojiKat = true;
                }
            }
            if(!postojiKat) {
                Kategorija nova = new Kategorija(nazivKategorije, "990");
                k.setKategorija(nova);
                kategorije.add(kategorije.size() - 1, nova);
                noveKategorije.add(nova);
                spinerAd.notifyDataSetChanged();
                spinner.setSelection(spinerAd.getPosition(nova));
            }

            int brojPitanja = Integer.parseInt(podijeliRed(list.get(0)).get(2));
            if(list.size() != brojPitanja + 1) {
                greska = true;
                openDialog("Kviz kojeg importujete ima neispravan broj pitanja!");
            }
            ArrayList<Pitanje> pitanja = new ArrayList<>();
            for(int i = 1; i < list.size(); i++) {
                String nazivPitanja = podijeliRed(list.get(i)).get(0);
                for(Pitanje pit : dodanaPit) {
                    if (pit.getNaziv().equals(nazivPitanja)) {
                        greska = true;
                        openDialog("Kviz nije ispravan, postoje dva pitanja sa istim nazivom!");
                        break;
                    }
                }

                int brojOdgovora = Integer.parseInt(podijeliRed(list.get(i)).get(1));
                int tacan = Integer.parseInt(podijeliRed(list.get(i)).get(2));
                if(tacan < 0 || tacan > brojOdgovora) {
                    openDialog("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
                    greska = true;
                }
                if(podijeliRed(list.get(i)).size() - 3 != brojOdgovora) {
                    openDialog("Kviz kojeg importujete ima neispravan broj odgovora!");
                    greska = true;
                }
                ArrayList<String> odgovori = new ArrayList<>();
                if(!greska) {
                    for (int j = 0; j < brojOdgovora; j++) {
                        if (odgovori.contains(podijeliRed(list.get(i)).get(3 + j))) {
                            openDialog("Kviz kojeg importujete nije ispravan, postoji ponavljanje odgovora!");
                            greska = true;
                            break;
                        } else
                            odgovori.add(podijeliRed(list.get(i)).get(3 + j));
                    }
                }
                if(!greska) {
                    editText.setText(nazivKviza);
                    k.setNaziv(nazivKviza);
                    pitanja.add(new Pitanje(nazivPitanja, nazivPitanja, odgovori, odgovori.get(tacan)));
                    dodanaPit.add(dodanaPit.size() - 1, new Pitanje(nazivPitanja, nazivPitanja, odgovori, odgovori.get(tacan)));
                    adapterDodana.notifyDataSetChanged();
                    kviz.setPitanja(pitanja);
                    sviKvizovi.add(kviz);
                }
            }
        }
    }

    private List<String> readTextFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        List<String> sadrzajPoRedovima = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            sadrzajPoRedovima.add(line);
        }
        return sadrzajPoRedovima;
    }
    private static List<String> podijeliRed(String s) {
        List<String> result = new ArrayList<>();
        String tmp = "";
        for(int i = 0; i < s.length(); i++) {
            while(i < s.length() && s.charAt(i) != ',')
                tmp += Character.toString(s.charAt(i++));
            result.add(tmp);
            tmp = "";
        }
        return result;
    }

    public void openDialog(String s) {
        CustomDialog dialog = CustomDialog.newInstance(s);
        dialog.show(getSupportFragmentManager(), "dialog");
    }

    private static ArrayList<String> dajId (ArrayList<Pitanje> arrayList) {
        ArrayList<String> res = new ArrayList<>();
        for(int i = 0; i < arrayList.size(); i++) {
            Pitanje pIzBaze = KvizoviAkt.dajPitanjeSaNazivom(KvizoviAkt.pitanjaDatabase, arrayList.get(i).getNaziv());
            if(pIzBaze != null)
                res.add(KvizoviAkt.pitanjaDatabase.get(pIzBaze));
        }
        return res;
    }

    private static Pair<Pitanje, String> nadjiPitanjeIId(Pitanje p) {
        Pair<Pitanje, String> res = null;
        for(Map.Entry<Pitanje, String> i : KvizoviAkt.pitanjaDatabase.entrySet()) {
            if(i.getKey().getNaziv().equals(p.getNaziv()))
                res = new Pair<>(i.getKey(), i.getValue());
        }
        return res;
    }

}
